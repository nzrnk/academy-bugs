let isPopupOpen = false; // Flag to prevent multiple triggers

function loadCssFile(filePath) {
  const link = document.createElement("link");
  link.rel = "stylesheet";
  link.type = "text/css";
  link.href = filePath; // Path to the CSS file
  document.head.appendChild(link);
}

// Load the CSS file for your theme
loadCssFile("/wp-content/themes/square/css/custom.css");

function setCookie(name, value, days) {
  var expires = "";
  if (days) {
    var date = new Date();
    date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
    expires = "; expires=" + date.toUTCString();
  }
  document.cookie = name + "=" + (value || "") + expires + "; path=/";
}
function getCookie(name) {
  var nameEQ = name + "=";
  var ca = document.cookie.split(";");
  for (var i = 0; i < ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == " ") c = c.substring(1, c.length);
    if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
  }
  return null;
}
function eraseCookie(name) {
  document.cookie = name + "=; Max-Age=-99999999;";
}
function validateEmail(email) {
  const re =
    /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(email);
}

function highlightElWithErrorLabel(el, labelId, elId, errMsg) {
  if (!el.parent().find("#" + labelId).length) {
    errMsg = errMsg === undefined ? "This field is required." : errMsg;
    if (labelId === "msg_error") el.css("margin-bottom", "-8px");
    el.css("border", "1px solid #cc0000");
    el.parent().append(
      '<label id="' +
        labelId +
        '" class="academyforms-error" for="' +
        elId +
        '">' +
        errMsg +
        "</label>"
    );
  }
}

function removeErrBelowFormField(el, labelId) {
  el.css("border", "1px solid #DDD");
  jQuery("#" + labelId).remove();
}

function validateAndModifyContactFormField(valObj, el, errLabelId, elId) {
  if (!jQuery.trim(el.val()).length) {
    valObj.isValid = false;
    if (elId === "email") jQuery("#email_validation_error").remove();
    highlightElWithErrorLabel(el, errLabelId, elId);
  } else {
    if (elId === "email") {
      jQuery("#empty_email_error").remove();
      if (validateEmail(el.val())) {
        removeErrBelowFormField(el, "email_validation_error");
      } else {
        valObj.isValid = false;
        highlightElWithErrorLabel(
          el,
          "email_validation_error",
          elId,
          "Please enter a valid email address."
        );
      }
    } else removeErrBelowFormField(el, errLabelId);
  }
}

function validateForm() {
  var firstName = jQuery('input[name="first_name"]');
  var lastName = jQuery('input[name="last_name"]');
  var email = jQuery('input[name="email"]');
  var subject = jQuery('input[name="subject"]');
  var message = jQuery('textarea[name="message"]');
  var validationObj = {
    isValid: true,
  };
  validateAndModifyContactFormField(
    validationObj,
    firstName,
    "first_name_error",
    "first_name"
  );
  validateAndModifyContactFormField(
    validationObj,
    lastName,
    "last_name_error",
    "last_name"
  );
  validateAndModifyContactFormField(
    validationObj,
    email,
    "empty_email_error",
    "email"
  );
  validateAndModifyContactFormField(
    validationObj,
    subject,
    "subject_error",
    "subject"
  );
  validateAndModifyContactFormField(
    validationObj,
    message,
    "msg_error",
    "message"
  );
  return validationObj.isValid;
}

function setPopupBugTitle(bugTitle) {
  jQuery(".academy-popup-bug-title").text(bugTitle);
}
function setPopupBugSubtitle(subtitle) {
  jQuery(".academy-popup-bug-subtitle").text(subtitle);
}
function setPopupBugSeverity(severity) {
  jQuery(".academy-popup-bug-severity").text(severity);
}
function setPopupBugType(bugType) {
  jQuery(".academy-popup-bug-type").text(bugType);
}
function setPopupBugFrequency(bugFrequency) {
  jQuery(".academy-popup-bug-frequency").text(bugFrequency);
}
function setPopupBugEnvironment(bugEnvironment) {
  jQuery(".academy-popup-bug-environment").text(bugEnvironment);
}
function setPopupBugSteps(bugSteps) {
  jQuery(".academy-popup-bug-steps").html(bugSteps);
}
function setPopupBugExpectedResult(expectedResult) {
  jQuery(".academy-popup-bug-expected-result").html(expectedResult);
}
function setPopupBugActualResult(actualResult) {
  jQuery(".academy-popup-bug-actual-result").html(actualResult);
}
function setPopupBugGif(bugGif) {
  jQuery(".academy-popup-gif img").attr("src", bugGif);
}
function setPopupBugImage(bugImage) {
  jQuery(".academy-popup-image-1 img").attr("src", bugImage);
}

var frequency = "Every Time";
var env = "All Browsers";

function loadTypesPopup(typeOfBugIndex) {
  var typesOfBugs = {
    functional: {
      subtitle:
        "Workflow failures producing an unexpected or illogical application behavior where the actual result differs from the expected result.",
      severity: "Medium",
      bugType: "Functional",
      steps:
        '<li>Open the <a href="https://academybugs.com/opportunities-we-provide" target="_blank" rel="noopener noreferrer" id="fn_bug"><b>Opportunities We Provide</b></a> page</li>' +
        '<li>Click the "Apply now" button at the bottom</li>',
      expResult: "To see an appropriate page after clicking on the button",
      actResult: "Nothing happens when clicking on the button",
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/T1.png",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/T1.gif",
    },
    visual: {
      subtitle:
        "Visual issues affect the layout and cause user interface distortion such as missing elements or images on a page.",
      severity: "Low",
      bugType: "Visual",
      steps:
        '<li>Open the <a href="https://academybugs.com/articles/" target="_blank" rel="noopener noreferrer"><b>Articles</b></a> page</li>' +
        "<li>Scroll down to the last article</li>",
      expResult: "To see the last articles's image",
      actResult: "The last article's image is broken",
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/T2.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/T2.png",
    },
    content: {
      subtitle:
        "Content issues affect the text of a page, such as spelling, grammar and localization errors.",
      severity: "Low",
      bugType: "Content",
      steps:
        '<li>Open the <a href="https://academybugs.com/frequently-asked-questions/" id="ct_bug" target="_blank" rel="noopener noreferrer"><b>Frequently Asked Questions</b></a> page</li>',
      expResult: "To see the page in English",
      actResult: "Some parts of the page are not translated",
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/T3.gif",
      imgImg:
        "https://academybugs.com/wp-content/uploads/2020/11/Content-type-example.png",
    },
    performance: {
      subtitle:
        "Problematic slowness or hanging, sluggish interface. Features take longer to load than they should, slow navigation in the application.",
      severity: "High",
      bugType: "Performance",
      steps:
        '<li>Open the <a href="https://academybugs.com/request-a-quote/" id="pn_bug" target="_blank" rel="noopener noreferrer"><b>Request a Quote</b></a> page</li>',
      expResult: "The page loads in a timely manner",
      actResult: "The page loads infinitely",
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/T4.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/T4.png",
    },
    crash: {
      subtitle:
        "Application quits or closes unexpectedly while using the features.",
      severity: "Critical",
      bugType: "Crash",
      steps:
        '<li>Open the <a href="https://academybugs.com/what-we-offer" id="cs_bug" target="_blank" rel="noopener noreferrer"><b>What We Offer</b></a> page</li>' +
        "<li>Click on the second page button at the bottom</li>",
      expResult: "The second page opens as expected",
      actResult:
        "The entire page including the links and buttons become unresponsive",
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/T5.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/T5.png",
    },
  };
  jQuery(".types-of-bugs-popup-title").html(
    typesOfBugs[typeOfBugIndex]["bugType"]
  );
  jQuery(".types-of-bugs-popup-subtitle").html(
    typesOfBugs[typeOfBugIndex]["subtitle"]
  );
  jQuery(".types-of-bugs-popup-severity").html(
    typesOfBugs[typeOfBugIndex]["severity"]
  );
  jQuery(".types-of-bugs-popup-type").html(
    typesOfBugs[typeOfBugIndex]["bugType"]
  );
  jQuery(".types-of-bugs-popup-frequency").html(frequency);
  jQuery(".types-of-bugs-popup-environment").html(env);
  jQuery(".types-of-bugs-popup-steps").html(
    typesOfBugs[typeOfBugIndex]["steps"]
  );
  jQuery(".types-of-bugs-popup-expected-result").html(
    typesOfBugs[typeOfBugIndex]["expResult"]
  );
  jQuery(".types-of-bugs-popup-actual-result").html(
    typesOfBugs[typeOfBugIndex]["actResult"]
  );
  jQuery(".types-of-bugs-popup-gif img").attr(
    "src",
    typesOfBugs[typeOfBugIndex]["gifImg"]
  );
  jQuery(".types-of-bugs-popup-image img").attr(
    "src",
    typesOfBugs[typeOfBugIndex]["imgImg"]
  );
}

function loadExamplePopup(exampleIndex) {
  var examplesOfBugs = [
    {
      bugTitle: "Social share buttons don’t work",
      subtitle:
        "Many websites have buttons for sharing information, but in this example those buttons don’t work.",
      severity: "Low",
      steps:
        '<li>Open the <a href="https://academybugs.com/articles/" id="low_s" target="_blank" rel="noopener noreferrer"><b>Articles List</b></a></li>' +
        "<li>Click on the social share buttons at the bottom of the posts to share them</li>",
      expResult:
        "To be able to share posts using the social media share buttons",
      actResult: "The social share buttons don't lead to anywhere",
      gifImg:
        "https://academybugs.com/wp-content/uploads/2020/10/Example-1-October.gif",
      imgImg:
        "https://academybugs.com/wp-content/uploads/2020/10/Example-1-October-Updated.png",
    },
    {
      bugTitle: "Send button returns an error page",
      subtitle:
        "Users should be able to send a message when clicking Send, but in this example the button returns an error page.",
      severity: "Medium",
      bugType: "Functional",
      steps:
        '<li>Open the <a href="https://academybugs.com/contact-us-form/" target="_blank" id="medium_s" rel="noopener noreferrer"><b>Contact Us Form</b></a></li>' +
        "<li>Fill out the form and click Send</li>",
      expResult: "The message is sent through the contact us form",
      actResult:
        'After filling out the form and clicking the "Send" button, an error message is displayed',
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/E2.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/E2.png",
    },
    {
      bugTitle: "Video player doesn’t work",
      subtitle:
        "Video players should quickly buffer and play video files, but in this example some videos can’t be played.",
      severity: "High",
      steps:
        '<li>Open the&nbsp;<a href="https://academybugs.com/latest-news/" target="_blank" rel="noopener noreferrer"><b>Latest news page</b></a></li>' +
        "<li>Try to play the videos on the left column</li>",
      expResult: "The videos in the left column are played back",
      actResult: "A black screen is shown instead of videos in the left column",
      gifImg:
        "https://academybugs.com/wp-content/uploads/2020/10/Example-3-October.gif",
      imgImg:
        "https://academybugs.com/wp-content/uploads/2024/04/Example-3.png",
    },
    {
      bugTitle: "Articles show an error page",
      subtitle:
        "The articles should show appropriate content, but in this example clicking an article shows an error page.",
      severity: "High",
      steps:
        '<li>Open&nbsp;the <a href="https://academybugs.com/articles/" target="_blank" rel="noopener noreferrer"><b>Articles list</b></a></li>' +
        "<li>Open an article by clicking on the image, title or the Read More button</li>",
      expResult: "The articles show appropriate content",
      actResult: "Clicking on all articles open an error page",
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/E4.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/E5.png",
    },
    {
      bugTitle: "Search button leads to an error",
      subtitle:
        "A search button should find appropriate results, but in this example clicking on it leads to an error page.",
      severity: "High",
      steps:
        '<li>Open the <a class="example-5-search-bug" href="https://academybugs.com/store/dnk-yellow-shoes/" target="_blank" rel="noopener noreferrer"><b>Product Details Page</b></a></li>' +
        '<li>On right side type the same product\'s name and hit "Search"</li>',
      expResult: "Appropriate results are found",
      actResult: "Clicking on the 'Search' button leads to an error page",
      gifImg:
        "https://academybugs.com/wp-content/uploads/2020/10/Example-5-October.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/E4.png",
    },
    {
      bugTitle: "Booking a table doesn't work",
      subtitle:
        "The user should be able to book a table, but in this example the user cannot submit the booking form.",
      severity: "Critical",
      steps:
        '<li>Open the <a href="https://academybugs.com/events/my-bookings/" target="_blank" id="high_s" rel="noopener noreferrer"><b>Table Reservation form</b></a></li>' +
        '<li>Fill out the form</li><li>Click "Request Booking"</li>',
      expResult:
        "The form is submitted successfully and a confirmation message is shown",
      actResult: "The same page is shown again",
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/E6.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/E6.png",
    },
  ];
  jQuery(".example-popup-bug-title").html(
    examplesOfBugs[exampleIndex - 1]["bugTitle"]
  );
  jQuery(".example-popup-subtitle").html(
    examplesOfBugs[exampleIndex - 1]["subtitle"]
  );
  jQuery(".example-popup-bug-severity").html(
    examplesOfBugs[exampleIndex - 1]["severity"]
  );
  jQuery(".example-popup-bug-type").html("Functional");
  jQuery(".example-popup-bug-frequency").html(frequency);
  jQuery(".example-popup-bug-environment").html(env);
  jQuery(".example-popup-bug-steps").html(
    examplesOfBugs[exampleIndex - 1]["steps"]
  );
  jQuery(".example-popup-bug-expected-result").html(
    examplesOfBugs[exampleIndex - 1]["expResult"]
  );
  jQuery(".example-popup-bug-actual-result").html(
    examplesOfBugs[exampleIndex - 1]["actResult"]
  );
  jQuery(".example-popup-bug-gif img").attr(
    "src",
    examplesOfBugs[exampleIndex - 1]["gifImg"]
  );
  jQuery(".example-popup-bug-image img").attr(
    "src",
    examplesOfBugs[exampleIndex - 1]["imgImg"]
  );
}

// function load25BugsPopupData(popupData, includeEncouragingMessage = false) {
//     if (includeEncouragingMessage) {
//         updatePopupTitle();
//     } else {
//         setPopupBugTitle(popupData["bug-title"]);
//     }
//     setPopupBugSubtitle(popupData["bug-subtitle"]);
//     setPopupBugSeverity(popupData["bug-severity"]);
//     setPopupBugType(popupData["bug-type"]);
//     setPopupBugFrequency(popupData["bug-frequency"]);
//     setPopupBugEnvironment(popupData["bug-environment"]);
//     setPopupBugSteps(popupData["bug-steps"]);
//     setPopupBugExpectedResult(popupData["bug-expected-result"]);
//     setPopupBugActualResult(popupData["bug-actual-result"]);
//     setPopupBugGif(popupData["bug-gif"]);
//     setPopupBugImage(popupData["bug-image"]);
// }

function loadPopUpImageAndGif(bugIndex, includeEncouragingMessage) {
  // Prototype ID 4406
  includeEncouragingMessage =
    includeEncouragingMessage === undefined ? false : includeEncouragingMessage;
  // if (localStorage.getItem("popups-content") != null){
  //     var parsedPopupsContent = JSON.parse(localStorage.getItem("popups-content"));
  //     if (parsedPopupsContent.hasOwnProperty(bugIndex)){
  //         var popupData = parsedPopupsContent[bugIndex];
  //         load25BugsPopupData(popupData, includeEncouragingMessage);
  //     } else {
  //         var myJson = jQuery.getJSON( "https://academybugs.com/wp-json/ac/v1/popup_data", {popup_index: bugIndex}, function(data) {
  //         parsedPopupsContent[bugIndex] = JSON.parse(data);
  //         localStorage.setItem('popups-content', JSON.stringify(parsedPopupsContent));
  //         load25BugsPopupData(parsedPopupsContent[bugIndex], includeEncouragingMessage);
  //         })
  //         .fail(function(err) {
  //         });
  //     }
  // } else {
  //     var myJson = jQuery.getJSON( "https://academybugs.com/wp-json/ac/v1/popup_data", {popup_index: bugIndex}, function(data) {
  //     var popupsContent = {};
  //     popupsContent[bugIndex] = JSON.parse(data);
  //     localStorage.setItem('popups-content', JSON.stringify(popupsContent));
  //     load25BugsPopupData(popupsContent[bugIndex], includeEncouragingMessage);
  //     });
  // }
  var bugs = {
    first: {
      bugTitle: "You found a “Functional” bug",
      subtitle: "In this bug, the product quantity cannot be increased past 2.",
      severity: "High",
      bugType: "Functional",
      steps:
        '<li>Open <a href="https://academybugs.com" target="_blank" rel="noopener noreferrer"><b>https://academybugs.com</b></a></li>' +
        "<li>Click the Find Bugs link on the navigation bar</li>" +
        '<li>Add one or more products to the cart</li><li>Click the "View cart" link on top of the page</li>' +
        '<li>Set the products quantity to 3 or more</li><li>Click "update" below</li>',
      expResult: "The product quantity can be increased past 2",
      actResult:
        "When clicking on the update button the product quantity becomes 2 again",
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/1.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/1.png",
    },
    second: {
      bugTitle: "You found a “Functional” bug",
      subtitle:
        "In this bug, the grand total is $100 more than the sum of all products in the cart.",
      severity: "Critical",
      bugType: "Functional",
      steps:
        '<li>Open <a href="https://academybugs.com" target="_blank" rel="noopener noreferrer"><b>https://academybugs.com</b></a></li>' +
        "<li>Click the Find Bugs link on the navigation bar</li>" +
        "<li>Add one or more products to the cart</li>" +
        '<li>Click the "View cart" link on top of the page, or click "Continue to Shipping" in the checkout details page</li>',
      expResult:
        "The grand total is equal to the sum of all products in the cart",
      actResult:
        "The grand total is $100 more than the sum of all products in the cart",
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/F2.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/2-1.png",
    },
    third: {
      bugTitle: "You found a “Functional” bug",
      subtitle:
        "In this bug, the manufacturer link in the product details page is broken.",
      severity: "Medium",
      bugType: "Functional",
      steps:
        '<li>Open <a href="https://academybugs.com" target="_blank" rel="noopener noreferrer"><b>https://academybugs.com</b></a></li>' +
        "<li>Click the Find Bugs link on the navigation bar</li>" +
        "<li>Open a product</li><li>Click the manufacturer link under the quantity</li>",
      expResult: "The manufacturer link shows an appropriate page",
      actResult: "The manufacturer link opens an error page",
      gifImg: "https://academybugs.com/wp-content/uploads/2020/11/Fn3.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/11/Fn3.png",
    },
    fourth: {
      bugTitle: "You found a “Functional” bug",
      subtitle:
        "In this bug, the filter by price doesn't work in the product details or product list pages.",
      severity: "Medium",
      bugType: "Functional",
      steps:
        '<li>Open <a href="https://academybugs.com" target="_blank" rel="noopener noreferrer"><b>https://academybugs.com</b></a></li>' +
        "<li>Click the Find Bugs link on the navigation bar</li>" +
        "<li>Open a product</li><li>On the right side menu find the Filter by Price section</li>" +
        "<li>Select any of the price ranges</li>" +
        "<li>Also open any item from the right side Store Menu and select the price ranges on the right side menu</li>",
      expResult: "A list of products in the selected price range is shown",
      actResult: "The same page reloads",
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/4.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/F4.png",
    },
    fifth: {
      bugTitle: "You found a “Functional” bug",
      subtitle:
        "In this bug, the twitter share button in the product details page is broken.",
      severity: "Medium",
      bugType: "Functional",
      steps:
        '<li>Open <a href="https://academybugs.com" target="_blank" rel="noopener noreferrer"><b>https://academybugs.com</b></a></li>' +
        "<li>Click the Find Bugs link on the navigation bar</li>" +
        "<li>Open a product</li><li>Click the twitter share button</li>",
      expResult: "The twitter share button shows an appropriate page",
      actResult: "The twitter share button shows an error page",
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/5.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/5.png",
    },
    sixth: {
      bugTitle: "You found a “Visual” bug",
      subtitle: "In this bug, the image is not completely displayed.",
      severity: "Medium",
      bugType: "Visual",
      steps:
        '<li>Open <a href="https://academybugs.com" target="_blank" rel="noopener noreferrer"><b>https://academybugs.com</b></a></li>' +
        "<li>Click the Find Bugs link on the navigation bar</li>" +
        '<li>Click on "Dark Grey Jeans"</li>',
      expResult: "The product image fills the box entirely",
      actResult: "The image has a white space on the right",
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/Find-6.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/6.png",
    },
    seventh: {
      bugTitle: "You found a “Visual” bug",
      subtitle:
        "In this bug, the caption of the Sign In button is misaligned vertically.",
      severity: "Low",
      bugType: "Visual",
      steps:
        '<li>Open <a href="https://academybugs.com" target="_blank" rel="noopener noreferrer"><b>https://academybugs.com</b></a></li>' +
        "<li>Click the Find Bugs link on the navigation bar</li>" +
        "<li>Open a product</li>" +
        "<li>Scroll to the bottom and find the sign in form in the right side menu</li>" +
        '<li>Enter any login and password that are not registered and click "Sign In"</li>',
      expResult: "The caption of the Sign In button is centered vertically",
      actResult: "The caption of the Sign In button is misaligned vertically",
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/F7.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/7.png",
    },
    eighth: {
      bugTitle: "You found a “Visual” bug",
      subtitle: "In this bug, item images have unnecessary space underneath.",
      severity: "Low",
      bugType: "Visual",
      steps:
        '<li>Open <a href="https://academybugs.com" target="_blank" rel="noopener noreferrer"><b>https://academybugs.com</b></a></li>' +
        "<li>Click the Find Bugs link on the navigation bar</li>" +
        "<li>Open a product</li>" +
        "<li>Find the Store Menu section in the right side menu</li>" +
        "<li>Choose All Items</li>",
      expResult: "Item images have no space underneath",
      actResult: "Item images have unnecessary space underneath",
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/F8.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/8.png",
    },
    ninth: {
      bugTitle: "You found a “Visual” bug",
      subtitle: "In this bug, the Sign In button overlaps the footer.",
      severity: "Low",
      bugType: "Visual",
      steps:
        '<li>Open <a href="https://academybugs.com" target="_blank" rel="noopener noreferrer"><b>https://academybugs.com</b></a></li>' +
        "<li>Click the Find Bugs link on the navigation bar</li>" +
        "<li>Open a product with no color selection options</li>" +
        "<li>Scroll down to the bottom of the right side menu</li>",
      expResult: "The Sign In button is above the footer",
      actResult: "The Sign In button overlaps the footer",
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/F9.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/F9.png",
    },
    tenth: {
      bugTitle: "You found a “Visual” bug",
      subtitle: "In this bug, the title of the password field is misaligned.",
      severity: "Low",
      bugType: "Visual",
      steps:
        '<li>Open <a href="https://academybugs.com" target="_blank" rel="noopener noreferrer"><b>https://academybugs.com</b></a></li>' +
        "<li>Click the Find Bugs link on the navigation bar</li>" +
        "<li>Open a product</li>" +
        "<li>Scroll down to the bottom of the right side menu</li>" +
        '<li>Click "Sign In" without filling the form to open the Sign In page</li>',
      expResult:
        "The title of the password field is aligned the same as the field above",
      actResult:
        "The title of the password field is not aligned the same as the field above",
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/F10.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/10.png",
    },
    eleventh: {
      bugTitle: "You found a “Content” bug",
      subtitle:
        "In this bug, the text under the New User section is not in English.",
      severity: "Low",
      bugType: "Content",
      steps:
        '<li>Open <a href="https://academybugs.com" target="_blank" rel="noopener noreferrer"><b>https://academybugs.com</b></a></li>' +
        "<li>Click the Find Bugs link on the navigation bar</li>" +
        "<li>Open a product</li>" +
        "<li>Scroll down to the bottom of the right side menu</li>" +
        '<li>Click "Sign In" to open the sign in page</a></li>',
      expResult: "The text under the New User section is in English",
      actResult: "The text under the New User section is in another language",
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/F11.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/11.png",
    },
    twelfth: {
      bugTitle: "You found a “Content” bug",
      subtitle:
        "In this bug, there are unreadable symbols in the shopping cart popup.",
      severity: "Low",
      bugType: "Content",
      steps:
        '<li>Open <a href="https://academybugs.com" target="_blank" rel="noopener noreferrer"><b>https://academybugs.com</b></a></li>' +
        "<li>Click the Find Bugs link on the navigation bar</li>" +
        "<li>Add one or more products to the cart</li>" +
        '<li>Click "View Cart" on top of the page</li>' +
        "<li>Scroll down to the Shopping Cart section of the right side menu</li>" +
        "<li>Hover over the Shopping Cart caption</a></li>",
      expResult: "All characters are clear to a regular user",
      actResult: "There are unreadable symbols in the shopping cart popup",
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/F12.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/Find-12.png",
    },
    thirteenth: {
      bugTitle: "You found a “Content” bug",
      subtitle:
        "In this bug, the short description and description of the product are not in English.",
      severity: "Medium",
      bugType: "Content",
      steps:
        '<li>Open <a href="https://academybugs.com" target="_blank" rel="noopener noreferrer"><b>https://academybugs.com</b></a></li>' +
        "<li>Click the Find Bugs link on the navigation bar</li>" +
        "<li>Open a product</li>",
      expResult:
        "The short description and description of the product are in English",
      actResult:
        "The short description and description of the product are not in English",
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/Find-13.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/Find-13.png",
    },
    fourteenth: {
      bugTitle: "You found a “Content” bug",
      subtitle:
        "In this bug, the yellow and orange colors of the product are misspelled.",
      severity: "Low",
      bugType: "Content",
      steps:
        '<li>Open <a href="https://academybugs.com" target="_blank" rel="noopener noreferrer"><b>https://academybugs.com</b></a></li>' +
        "<li>Click the Find Bugs link on the navigation bar</li>" +
        "<li>Open a product with color options</li>" +
        "<li>Choose the Yellow and Orange colors</li>",
      expResult: "The yellow and orange colors are spelled correctly",
      actResult: 'Yellow is misspelled as "Yelow" and Orange as "Orang"',
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/14.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/14.png",
    },
    fifteenth: {
      bugTitle: "You found a “Content” bug",
      subtitle:
        'In this bug, there is big space before the last letter in "Return to Store".',
      severity: "Low",
      bugType: "Content",
      steps:
        '<li>Open <a href="https://academybugs.com" target="_blank" rel="noopener noreferrer"><b>https://academybugs.com</b></a></li>' +
        "<li>Click the Find Bugs link on the navigation bar</li>" +
        "<li>Open a product</li>" +
        "<li>Open the cart at the bottom of right side menu</li>" +
        "<li>Clear the cart if there are any items</li>",
      expResult:
        'The caption of the "Return to Store" button is written with even spacing between letters',
      actResult:
        'There is too much space before the last letter in "Return to Store"',
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/F15.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/15.png",
    },
    sixteenth: {
      bugTitle: "You found a “Performance” bug",
      subtitle: "In this bug, the billing information isn't updated.",
      severity: "High",
      bugType: "Performance",
      steps:
        '<li>Open <a href="https://academybugs.com" target="_blank" rel="noopener noreferrer"><b>https://academybugs.com</b></a></li>' +
        "<li>Click the Find Bugs link on the navigation bar</li>" +
        "<li>Open a product</li>" +
        '<li>Click "Sign Up" at the bottom of right side menu</li>' +
        "<li>Sign up with fake data if you are not signed up. Otherwise enter your credentials and log in</li>" +
        "<li>At the bottom of the right side menu select Billing Information</li>" +
        "<li>Fill out the billing information form</li>" +
        '<li>Click "Update"</li>',
      expResult:
        'Billing information is updated after filling out the form and clicking "Update"',
      actResult:
        'Billing information loads infinitely after filling out the form and clicking "Update"',
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/Find-16.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/Find-16.png",
    },
    seventeenth: {
      bugTitle: "You found a “Performance” bug",
      subtitle: "In this bug, the order history loads infinitely.",
      severity: "High",
      bugType: "Performance",
      steps:
        '<li>Open <a href="https://academybugs.com" target="_blank" rel="noopener noreferrer"><b>https://academybugs.com</b></a></li>' +
        "<li>Click the Find Bugs link on the navigation bar</li>" +
        "<li>Open a product</li>" +
        "<li>Sign up if you are not signed up or log in at the bottom of right side menu</li>" +
        "<li>At the bottom of the right side menu select Order History</li>",
      expResult: "Your Order History section shows appropriate info",
      actResult: "Your Order History section loads infinitely",
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/F17.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/17.png",
    },
    eighteenth: {
      bugTitle: "You found a “Performance” bug",
      subtitle: "In this bug, the billing address loads infinitely.",
      severity: "Medium",
      bugType: "Performance",
      steps:
        '<li>Open <a href="https://academybugs.com" target="_blank" rel="noopener noreferrer"><b>https://academybugs.com</b></a></li>' +
        "<li>Click the Find Bugs link on the navigation bar</li>" +
        "<li>Open a product</li>" +
        "<li>Sign up if you are not signed up or log in at the bottom of right side menu</li>" +
        "<li>At the bottom of the right side menu select Dashboard</li>" +
        "<li>Scroll up to the Billing Address section</li>",
      expResult: "The Billing Address section shows appropriate info",
      actResult: "The Billing Address section loads infinitely",
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/F18.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/18.png",
    },
    nineteenth: {
      bugTitle: "You found a “Performance” bug",
      subtitle:
        "In this bug, the product in the Hot Item section keeps loading.",
      severity: "High",
      bugType: "Performance",
      steps:
        '<li>Open <a href="https://academybugs.com" target="_blank" rel="noopener noreferrer"><b>https://academybugs.com</b></a></li>' +
        "<li>Click the Find Bugs link on the navigation bar</li>" +
        "<li>Open a product</li>" +
        "<li>Open the product in the Hot Item section of the right side menu</li>",
      expResult: "The product in the Hot Item section is displayed",
      actResult: "The page loads infinitely",
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/19.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/19.png",
    },
    twentieth: {
      bugTitle: "You found a “Performance” bug",
      subtitle: "In this bug, the My Space share page loads infinitely.",
      severity: "Low",
      bugType: "Performance",
      steps:
        '<li>Open <a href="https://academybugs.com" target="_blank" rel="noopener noreferrer"><b>https://academybugs.com</b></a></li>' +
        "<li>Click the Find Bugs link on the navigation bar</li>" +
        "<li>Open a product</li>" +
        "<li>Click the My Space share link</li>",
      expResult: "The user is able to share the product through My Space",
      actResult: "My Space share page loads infinitely",
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/20.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/20.png",
    },
    twentyFirst: {
      bugTitle: "You found a “Crash” bug",
      subtitle: "In this bug, the page freezes when changing the currency.",
      severity: "High",
      bugType: "Crash",
      steps:
        '<li>Open <a href="https://academybugs.com" target="_blank" rel="noopener noreferrer"><b>https://academybugs.com</b></a></li>' +
        "<li>Click the Find Bugs link on the navigation bar</li>" +
        "<li>Open a product</li>" +
        "<li>Change the currency in the right side menu</li>",
      expResult: "The currency is changed as expected",
      actResult: "The page freezes when changing the currency",
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/21.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/22.png",
    },
    twentySecond: {
      bugTitle: "You found a “Crash” bug",
      subtitle:
        "In this bug, the page becomes unresponsive when clicking on the numbers of results.",
      severity: "High",
      bugType: "Crash",
      steps:
        '<li>Open <a href="https://academybugs.com" target="_blank" rel="noopener noreferrer"><b>https://academybugs.com</b></a></li>' +
        "<li>Click the Find Bugs link on the navigation bar</li>" +
        "<li>Click on the buttons to show a certain number of results at the top left</li>",
      expResult:
        "The selected number of results is displayed according to the clicked buttons",
      actResult: "The page freezes when clicking on the numbers of results",
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/22.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/21.png",
    },
    twentyThird: {
      bugTitle: "You found a “Crash” bug",
      subtitle:
        "In this bug, the page becomes unresponsive when clicking on the Post Comment button.",
      severity: "High",
      bugType: "Crash",
      steps:
        '<li>Open <a href="https://academybugs.com" target="_blank" rel="noopener noreferrer"><b>https://academybugs.com</b></a></li>' +
        "<li>Click the Find Bugs link on the navigation bar</li>" +
        "<li>Open a product</li>" +
        "<li>Scroll down to the Leave a Reply section</li>" +
        "<li>Fill out the comment form</li>" +
        '<li>Click "Post Comment"</li>',
      expResult: "The comment is posted under the product",
      actResult:
        'The page becomes unresponsive when clicking on "Post Comment"',
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/23.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/23.png",
    },
    twentyFourth: {
      bugTitle: "You found a “Crash” bug",
      subtitle:
        "In this bug, the page becomes unresponsive when clicking on the Retrieve Password button.",
      severity: "High",
      bugType: "Crash",
      steps:
        '<li>Open <a href="https://academybugs.com" target="_blank" rel="noopener noreferrer"><b>https://academybugs.com</b></a></li>' +
        "<li>Click the Find Bugs link on the navigation bar</li>" +
        "<li>Open a product</li>" +
        "<li>Scroll down to the Your Account section of the right side menu</li>" +
        '<li>Click "Sign Up"</li>' +
        '<li>In the Returning Customer section click "Forgot Your Password?"</li>' +
        '<li>Enter your email in the field and click "Retrieve Password"</li>',
      expResult: "The password is sent to the entered email",
      actResult:
        'The page becomes unresponsive when clicking on "Retrieve Password" and no email is sent',
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/F24.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/24.png",
    },
    twentyFifth: {
      bugTitle: "You found a “Crash” bug",
      subtitle:
        "In this bug, the page freezes when increasing the product quantity having green or pink colors chosen.",
      severity: "High",
      bugType: "Crash",
      steps:
        '<li>Open <a href="https://academybugs.com" target="_blank" rel="noopener noreferrer"><b>https://academybugs.com</b></a></li>' +
        "<li>Click the Find Bugs link on the navigation bar</li>" +
        "<li>Open a product that has color options</li>" +
        "<li>Choose the pink or green color</li>" +
        "<li>Increase the product quantity by 1 or more</li>",
      expResult: "The quantity is increased to a desired value",
      actResult:
        "The page becomes unresponsive when increasing the quantity with the pink or green colors chosen",
      gifImg: "https://academybugs.com/wp-content/uploads/2020/10/25.gif",
      imgImg: "https://academybugs.com/wp-content/uploads/2020/10/25.png",
    },
  };
  jQuery(".academy-popup-bug-title").html(bugs[bugIndex]["bugTitle"]);
  jQuery(".academy-popup-bug-subtitle").html(bugs[bugIndex]["subtitle"]);
  jQuery(".academy-popup-bug-severity").html(bugs[bugIndex]["severity"]);
  jQuery(".academy-popup-bug-type").html(bugs[bugIndex]["bugType"]);
  jQuery(".academy-popup-bug-frequency").html("Every Time");
  jQuery(".academy-popup-bug-environment").html("All Browsers");
  jQuery(".academy-popup-bug-steps").html(bugs[bugIndex]["steps"]);
  jQuery(".academy-popup-bug-expected-result").html(
    bugs[bugIndex]["expResult"]
  );
  jQuery(".academy-popup-bug-actual-result").html(bugs[bugIndex]["actResult"]);
  jQuery(".academy-popup-gif img").attr("src", bugs[bugIndex]["gifImg"]);
  jQuery(".academy-popup-image-1 img").attr("src", bugs[bugIndex]["imgImg"]);
  if (includeEncouragingMessage) updatePopupTitle();
}

function showHintMessage(hintText, onCompleteCallback) {
  onCompleteCallback =
    onCompleteCallback === undefined ? function () {} : onCompleteCallback;
  jQuery(".popup-hint-message").text(hintText);
  popupOpenAndCloseWithoutTitle("4393", onCompleteCallback);
}

function showHintIfBugsAreNearby(bugIndex, onCompleteCallback) {
  onCompleteCallback =
    onCompleteCallback === undefined ? function () {} : onCompleteCallback;
  if (localStorage.getItem("found-bugs") != null) {
    var foundBugs = JSON.parse(localStorage.getItem("found-bugs"));
    var hintMsg = "";
    var bugHints = {
      first: {
        second: "There are more bugs in the cart page, please keep searching.",
        fifteenth: "Empty the cart and see if there's a bug.",
      },
      second: {
        first: "There are more bugs in the cart page, please keep searching.",
        fifteenth: "Empty the cart and see if there's a bug.",
      },
      third: {
        "fourth,fifth,ninth,twelfth,thirteenth,nineteenth,twentieth,twentyFirst,twentyThird":
          "There are more bugs in the product details page, please keep searching.",
        "fourteenth,twentyFifth": "Check a product with color options.",
      },
      fourth: {
        "thirteenth,twentyFirst,fifth,twentieth,twentyThird,third,twelfth,ninth,nineteenth":
          "There are more bugs in the product details page, please keep searching.",
        "fourteenth,twentyFifth": "Check a product with color options.",
      },
      fifth: {
        "thirteenth,twentyFirst,fourth,twentieth,twentyThird,third,twelfth,ninth,nineteenth":
          "There are more bugs in the product details page, please keep searching.",
        "fourteenth,twentyFifth": "Check a product with color options.",
      },
      sixth: {
        twentySecond:
          "There are more bugs in the find bugs page, please keep searching.",
      },
      seventh: {
        "tenth,eleventh,twentyFourth":
          "There are more bugs in the authentication section, please keep searching.",
      },
      ninth: {
        "thirteenth,twentyFirst,fourth,twentieth,twentyThird,third,twelfth,fifth,nineteenth":
          "There are more bugs in the product details page, please keep searching.",
        "fourteenth,twentyFifth": "Check a product with color options.",
      },
      tenth: {
        "seventh,eleventh,twentyFourth":
          "There are more bugs in the authentication section, please keep searching.",
      },
      eleventh: {
        "seventh,tenth,twentyFourth":
          "There are more bugs in the authentication section, please keep searching.",
      },
      twelfth: {
        "thirteenth,twentyFirst,fourth,twentieth,twentyThird,third,ninth,fifth,nineteenth":
          "There are more bugs in the product details page, please keep searching.",
        "fourteenth,twentyFifth": "Check a product with color options.",
      },
      thirteenth: {
        "twelfth,twentyFirst,fourth,twentieth,twentyThird,third,ninth,fifth,nineteenth":
          "There are more bugs in the product details page, please keep searching.",
        "fourteenth,twentyFifth": "Check a product with color options.",
      },
      fourteenth: {
        "twelfth,twentyFirst,fourth,twentieth,twentyThird,third,ninth,fifth,thirteenth,nineteenth":
          "There are more bugs in the product details page, please keep searching.",
        twentyFifth: "Check a product with color options.",
      },
      fifteenth: {
        "first,second":
          "There are more bugs in the cart page, please try adding items to the cart.",
      },
      sixteenth: {
        "seventeenth,eighteenth":
          "There are more bugs in the profile settings, please keep searching.",
      },
      seventeenth: {
        "sixteenth,eighteenth":
          "There are more bugs in the profile settings, please keep searching.",
      },
      eighteenth: {
        "sixteenth,seventeenth":
          "There are more bugs in the profile settings, please keep searching.",
      },
      nineteenth: {
        "twelfth,twentyFirst,fourth,twentieth,twentyThird,third,ninth,fifth,thirteenth":
          "There are more bugs in the product details page, please keep searching.",
        "fourteenth,twentyFifth": "Check a product with color options.",
      },
      twentieth: {
        "twelfth,twentyFirst,fourth,nineteenth,twentyThird,third,ninth,fifth,thirteenth":
          "There are more bugs in the product details page, please keep searching.",
        "fourteenth,twentyFifth": "Check a product with color options.",
      },
      twentyFirst: {
        "twelfth,twentieth,fourth,nineteenth,twentyThird,third,ninth,fifth,thirteenth":
          "There are more bugs in the product details page, please keep searching.",
        "fourteenth,twentyFifth": "Check a product with color options.",
      },
      twentySecond: {
        sixth:
          "There are more bugs in the find bugs page, please keep searching.",
      },
      twentyThird: {
        "twelfth,twentieth,fourth,nineteenth,twentyFirst,third,ninth,fifth,thirteenth":
          "There are more bugs in the product details page, please keep searching.",
        "fourteenth,twentyFifth": "Check a product with color options.",
      },
      twentyFourth: {
        "seventh,tenth,eleventh":
          "There are more bugs in the authentication section, please keep searching.",
      },
      twentyFifth: {
        "twelfth,twentieth,twentyThird,fourth,nineteenth,twentyFirst,third,ninth,fifth,thirteenth":
          "There are more bugs in the product details page, please keep searching.",
        fourteenth: "Check a product with color options.",
      },
    };
    if (bugHints.hasOwnProperty(bugIndex)) {
      var currentBugHints = bugHints[bugIndex];
      Object.keys(currentBugHints).forEach(function (key) {
        if (key.indexOf(",") >= 0) {
          var keys = key.split(",");
          for (let i = 0; i < keys.length; i++) {
            if (!foundBugs.hasOwnProperty(keys[i])) {
              hintMsg = hintMsg.length
                ? hintMsg + " Additionally: " + currentBugHints[key]
                : currentBugHints[key];
              break;
            }
          }
        } else if (!foundBugs.hasOwnProperty(key)) {
          if (hintMsg.length)
            hintMsg = hintMsg + " Additionally: " + currentBugHints[key];
          else hintMsg = currentBugHints[key];
        }
      });
      if (hintMsg.length) showHintMessage(hintMsg, onCompleteCallback);
      else onCompleteCallback();
    }
  }
}

function updatePopupTitle() {
  jQuery(".academy-popup-title").ready(function (e) {
    const foundBugs = localStorage.getItem("found-bugs");
    if (foundBugs == null) {
      jQuery(".example-tile-heading").text(
        "#1 Awesome! You found a bug. Pretty easy right?"
      );
    } else {
      var foundBugsCount = Object.keys(JSON.parse(foundBugs)).length;
      var adjustedTitle = "You found " + foundBugsCount + " bugs.";
      var adjustedTitles = {
        1: "#1 Awesome! You found a bug. Pretty easy right?",
        5: "#5 Great job! You found 5 bugs already, having fun?",
        10: "#10 Way to go! You found 10 bugs, keep it up.",
        15: "#15 Alright! You found 15 bugs, there are 10 more.",
        20: "#20 Excellent! You found 20 bugs, there are 5 more.",
        25: "#25 Congratulations! You found all 25 bugs, nice work!",
      };
      if (adjustedTitles.hasOwnProperty(foundBugsCount))
        adjustedTitle = adjustedTitles[foundBugsCount];
      jQuery(".example-tile-heading").text(adjustedTitle);
    }
  });
}

function tooltipBugCountInfo() {
  const foundBugs = localStorage.getItem("found-bugs");
  incBadgeCounter();
  if (foundBugs != null) {
    var foundBugsCount = Object.keys(JSON.parse(foundBugs)).length;
    var bugOrBugs = foundBugsCount > 1 ? "bugs" : "bug";
    jQuery(".sfm-tool-tip .academy-sfm-tooltip-counter").text(
      "You found " + foundBugsCount + " " + bugOrBugs + " out of 25"
    );
    var i = 1;
    var parsedFoundBugs = JSON.parse(foundBugs);
    for (let key in parsedFoundBugs) {
      if (parsedFoundBugs.hasOwnProperty(key)) {
        jQuery(".tooltip-table-container>div:nth-child(" + i + ")").attr(
          "style",
          "display: block"
        );
        jQuery(
          ".tooltip-table-container>div:nth-child(" + i + ") > a"
        ).addClass("academy-tooltip-bug-" + key);
        i++;
      }
    }
  }
}

function incBadgeCounter() {
  const foundBugs = localStorage.getItem("found-bugs");
  if (foundBugs != null) {
    var foundBugsCount = Object.keys(JSON.parse(foundBugs)).length;
    if (foundBugsCount > 0) {
      jQuery("#bugs-counter-badge").css("visibility", "visible");
      jQuery("#bugs-counter-badge > span").text(foundBugsCount);
    }
  }
}

function incrementFoundBugsCount(bugElement, bugIndex, onCompleteCallback) {
  onCompleteCallback =
    onCompleteCallback === undefined ? function () {} : onCompleteCallback;
  if (localStorage.getItem("found-bugs") === null) {
    var tfbugs = {};
    tfbugs[bugIndex] = 1;
    localStorage.setItem("found-bugs", JSON.stringify(tfbugs));
    onCompleteCallback();
  } else {
    var foundBugs = JSON.parse(localStorage.getItem("found-bugs"));
    if (!foundBugs.hasOwnProperty(bugIndex)) {
      foundBugs[bugIndex] = 1;
      localStorage.setItem("found-bugs", JSON.stringify(foundBugs));
      onCompleteCallback();
    } else {
      onCompleteCallback();
    }
  }
}

function popupOpenAndClose(id, onClose) {
  onClose = onClose === undefined ? function () {} : onClose;
  console.log("pum open: #" + id);
  PUM.open(id);
  jQuery("#pum-" + id).one("pumAfterClose", function () {
    setPopupBugTitle("");
    setPopupBugSubtitle("");
    setPopupBugSeverity("");
    setPopupBugType("");
    setPopupBugFrequency("");
    setPopupBugEnvironment("");
    setPopupBugSteps("");
    setPopupBugExpectedResult("");
    setPopupBugActualResult("");
    setPopupBugGif("");
    setPopupBugImage("");
    onClose();
  });
}

function popupOpenAndCloseWithoutTitle(id, onClose) {
  onClose = onClose === undefined ? function () {} : onClose;
  PUM.open(id);
  jQuery("#pum-" + id).one("pumAfterClose", onClose);
}

//all my functions for the MCQs

// Function to Show Intermediate Popup
function showBugPopup(bugIndex, element) {
  const bug = bugData[bugIndex];
  const popupHtml = `
          <div id="bug-popup" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
              background: white; border: 2px solid #ccc; border-radius: 12px; padding: 20px;
              z-index: 9999; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2); font-family: Arial, sans-serif;">
  
              <div style="text-align: right;">
                  <span id="close-popup" style="position: fixed; cursor: pointer; top: 0%;right: 2%; font-weight: bold; font-size: 28px; color: #888;">&times;</span>
              </div>
              <h3 style="text-align: center; font-size: 1.5em; color: #333; margin-bottom: 15px;">What did you find out?</h3>
              
              <p style="font-weight: bold; margin-bottom: 10px;">${
                bug.question1
              }</p>
              <div>
                  ${bug.options1
                    .map(
                      (opt) => `
                      <label style="display: block; margin: 5px 0; font-size: 14px;">
                          <input type="radio" name="answer1" value="${opt}" style="margin-right: 5px;"> ${opt}
                      </label>`
                    )
                    .join("")}
              </div>
  
              <p style="font-weight: bold; margin-top: 15px; margin-bottom: 10px;">${
                bug.question2
              }</p>
              <div>
                  ${bug.options2
                    .map(
                      (opt) => `
                      <label style="display: block; margin: 5px 0; font-size: 14px;">
                          <input type="radio" name="answer2" value="${opt}" style="margin-right: 5px;"> ${opt}
                      </label>`
                    )
                    .join("")}
              </div>
              
              <div style="text-align: center; margin-top: 15px;">
                  <button id="submit-popup" style="padding: 10px 20px; background-color: #28a745; color: white;
                      border: none; border-radius: 5px; cursor: pointer; font-size: 14px;">
                      Submit
                  </button>
              </div>
          </div>
      `;

  const foundBugs = JSON.parse(localStorage.getItem("found-bugs")) || {};
  if (foundBugs.hasOwnProperty(bugIndex)) {
    loadPopUpImageAndGif(bugIndex, true);
    popupOpenAndClose(4406, function () {
      tooltipBugCountInfo();
      showHintIfBugsAreNearby(bugIndex, function () {
        if (bugIndex == "sixteenth") {
          location = "https://academybugs.com/account/";
        } else if (bugIndex == "nineteenth") {
          location = "https://academybugs.com/find-bugs/";
        } else if (bugIndex == "ninth") {
          jQuery("#login-from-side-menu").submit();
        } else if (bugIndex == "fifteenth") {
          location = "https://academybugs.com/find-bugs/";
        } else if (bugIndex == "sixth") {
          location = "https://academybugs.com/store/dark-grey-jeans/";
        } else if (bugIndex == "third") {
          location.reload(true);
        }
      });
    });
  } else {
    jQuery("body").append(popupHtml);
    jQuery("#bug-popup").hide().fadeIn(500);

    jQuery("#close-popup").click(() =>
      jQuery("#bug-popup").fadeOut(300, () => jQuery("#bug-popup").remove())
    );

    jQuery("#submit-popup").click(function () {
      const userAnswer1 = jQuery("input[name='answer1']:checked").val();
      const userAnswer2 = jQuery("input[name='answer2']:checked").val();

      if (!userAnswer1 || !userAnswer2) {
        alert("Please answer both questions before submitting!");
        return;
      }

      const isCorrect1 = userAnswer1 === bug.correct1;
      const isCorrect2 = userAnswer2 === bug.correct2;

      jQuery("#bug-popup").fadeOut(300, () => jQuery("#bug-popup").remove());
      showResultPopup(
        bugIndex,
        element,
        isCorrect1,
        isCorrect2,
        userAnswer1,
        userAnswer2,
        bug.hint
      );
    });
  }
}

// Function to Show Result Popup
function showResultPopup(
  bugIndex,
  element,
  isCorrect1,
  isCorrect2,
  userAnswer1,
  userAnswer2,
  hint
) {
  const bug = bugData[bugIndex];
  const resultHtml = `
          <div id="result-popup" style="width: 44%; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
              background: white; border: 2px solid #ccc; border-radius: 12px; padding: 20px; z-index: 9999;
              box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2); font-family: Arial, sans-serif; text-align: center;">
              <div style="text-align:left;">
              <h3 style="font-size: 1.5em; color: ${
                isCorrect1 && isCorrect2 ? "#28a745" : "#dc3545"
              };">
                  ${
                    isCorrect1 && isCorrect2
                      ? "✅ Correct!"
                      : "Oops! You selected one or more wrong options."
                  }
              </h3>
                          <ol type="1">
                              <li>
                      <strong><u>Issue Type</u></strong>
                      <br><strong>Your Answer: </strong>
                      ${
                        isCorrect1
                          ? `<br>✅ <strong>${userAnswer1}</strong> is the correct issue type`
                          : `<br>❌ Oops! <strong>${userAnswer1}</strong> is not the right answer. Think again!`
                      }
                  </li>
                  <br>
                  <li>
                      <strong><u>Expected Results</u></strong>
                      <br><strong>Your Answer: </strong>
                      <br>
                      ${
                        isCorrect2
                          ? `✅ <strong>"${userAnswer2}"</strong> is Correct `
                          : `❌ <strong>"${userAnswer2}"</strong> - Ahh! Incorrect answer, want to retry?`
                      }
                  </li>
              </ol>
   </div>
              ${
                !(isCorrect1 && isCorrect2)
                  ? `<p style="color: #880808; font-weight: bold; margin-top: 10px;">Hint: ${hint}</p>`
                  : ``
              }
                 
              <div style="margin-top: 15px;">
                  ${
                    !(isCorrect1 && isCorrect2)
                      ? `<button id="retry" style="padding: 10px 20px; background-color: #00a8cc; color: white;
                          border: none; border-radius: 5px; cursor: pointer; margin-right: 10px;"><strong>Retry</strong></button>`
                      : ""
                  }
                      ${
                        isCorrect1 || isCorrect2
                          ? `<button id="view-report" style="padding: 10px 20px; background-color: #00a8cc; color: white;
                      border: none; border-radius: 5px; cursor: pointer;"><strong>View Issue Report</strong></button>`
                          : ""
                      }
                  
              </div>
          </div>
      `;
  jQuery("body").append(resultHtml);
  jQuery("#result-popup").hide().fadeIn(500);

  jQuery("#close-popup").click(() =>
    jQuery("#result-popup").fadeOut(300, () => jQuery("#result-popup").remove())
  );

  jQuery("#retry").click(() => {
    jQuery("#result-popup").remove();
    showBugPopup(bugIndex, element);
  });

  jQuery("#view-report").click(() => {
    jQuery("#result-popup").remove();
    triggerBugActions(bugIndex, element);
  });
}

// Function to Trigger Existing Bug Actions
function triggerBugActions(bugIndex, element) {
  incrementFoundBugsCount(element, bugIndex, function () {
    loadPopUpImageAndGif(bugIndex, true);
    popupOpenAndClose(4406, function () {
      tooltipBugCountInfo();

      showHintIfBugsAreNearby(bugIndex, function () {
        if (bugIndex == "sixteenth") {
          location = "https://academybugs.com/account/";
        } else if (bugIndex == "nineteenth") {
          location = "https://academybugs.com/find-bugs/";
        } else if (bugIndex == "ninth") {
          jQuery("#login-from-side-menu").submit();
        } else if (bugIndex == "fifteenth") {
          location = "https://academybugs.com/find-bugs/";
        } else if (bugIndex == "sixth") {
          location = "https://academybugs.com/store/dark-grey-jeans/";
        } else if (bugIndex == "third") {
          location.reload(true);
        }
      });
    });
  });
}

// Questions, Options, and Correct Answers for Each Bug
const bugData = {
  second: {
    question1: "What type of issue is it?",
    options1: ["Functional", "Visual", "Content", "Performance", "Crash"],
    correct1: "Functional",
    question2: "What should be the expected result?",
    options2: [
      "The amount should be in our local currency",
      "The grand total is equal to the sum of all products in the cart",
      "The grand total should not be bold text",
      "Shipping cost is not added in the grand total",
    ],
    correct2: "The grand total is equal to the sum of all products in the cart",
    hint: "Check the total value of items in the cart",
  },
  third: {
    question1: "What type of issue is it?",
    options1: ["Functional", "Visual", "Content", "Performance", "Crash"],
    correct1: "Functional",
    question2: "What should be the expected result?",
    options2: [
      "The amount should be in our local currency",
      "The text color should be black by default",
      "The manufacturer link shows an appropriate page",
      "The price range should not be shown on this page",
    ],
    correct2: "The manufacturer link shows an appropriate page",
    hint: "Do you see the Manufacturer details on the Manufacture's link?",
  },
  fourth: {
    question1: "What type of issue is it?",
    options1: ["Functional", "Visual", "Content", "Performance", "Crash"],
    correct1: "Functional",
    question2: "What should be the expected result?",
    options2: [
      "The amount should be in our local currency",
      "The text color should be black by default",
      "A list of products in the selected price range is shown",
      "The price range should not be shown on this page",
    ],
    correct2: "A list of products in the selected price range is shown",
    hint: "Check if you are seeing all the products in the selected range or not",
  },
  fifth: {
    question1: "What type of issue is it?",
    options1: ["Functional", "Visual", "Content", "Performance", "Crash"],
    correct1: "Functional",
    question2: "What should be the expected result?",
    options2: [
      "The color of the twitter icon should be blue and white by default",
      "Clicking on Twitter should ask for our twitter username",
      "Twitter icon should take the user to twitter",
      "The twitter share button should show an appropriate page to share the product on Twitter",
    ],
    correct2:
      "The twitter share button should show an appropriate page to share the product on Twitter",
    hint: "What is happening when you click on the twitter icon?",
  },
  sixth: {
    question1: "What type of issue is it?",
    options1: ["Functional", "Visual", "Content", "Performance", "Crash"],
    correct1: "Visual",
    question2: "What should be the expected result?",
    options2: [
      "The name of the product should be 'Gray Jeans' instead of 'Grey Jeans'",
      "Clicking on the jeans image should enlarge the image size",
      "The image background should be brown in color",
      "The product image fills the box entirely just like all other product images",
    ],
    correct2:
      "The product image fills the box entirely just like all other product images",
    hint: "Is the size of the product image correct?",
  },
  eighth: {
    question1: "What type of issue is it?",
    options1: ["Functional", "Visual", "Content", "Performance", "Crash"],
    correct1: "Visual",
    question2: "What should be the expected result?",
    options2: [
      "Price of the products should be same as on the Product Display Page",
      "Each product should have the same background",
      "Product images have no space underneath",
      "Each product should have 'Add to Cart' button",
    ],
    correct2: "Product images have no space underneath",
    hint: "Check the extra space beneath the images",
  },
  ninth: {
    question1: "What type of issue is it?",
    options1: ["Functional", "Visual", "Content", "Performance", "Crash"],
    correct1: "Visual",
    question2: "What should be the expected result?",
    options2: [
      "The button should be Log In instead of Sign In",
      "The Sign In button should be above the footer",
      "The Sign in button should take the user to the Dashboard",
      "The Sign in button should take the user to Sign in page",
    ],
    correct2: "The Sign In button should be above the footer",
    hint: "Check the alignment of the button",
  },
  tenth: {
    question1: "What type of issue is it?",
    options1: ["Functional", "Visual", "Content", "Performance", "Crash"],
    correct1: "Visual",
    question2: "What should be the expected result?",
    options2: [
      "Hovering on password label should tell about password requirements",
      "The Password label should aligned to the center",
      "The Password label should aligned to the left",
      "Clicking on password label should suggest a strong password",
    ],
    correct2: "The Password label should aligned to the left",
    hint: "Check the alignment of the label",
  },
  eleventh: {
    question1: "What type of issue is it?",
    options1: ["Functional", "Visual", "Content", "Performance", "Crash"],
    correct1: "Content",
    question2: "What should be the expected result?",
    options2: [
      "The website should be in the user's local language",
      "The text under the New User section is in English",
      "User should have a translate button to translate the text in your local language",
      "The font-size should be larger",
    ],
    correct2: "The text under the New User section is in English",
    hint: "Check the language of the text",
  },
  twelfth: {
    question1: "What type of issue is it?",
    options1: ["Functional", "Visual", "Content", "Performance", "Crash"],
    correct1: "Content",
    question2: "What should be the expected result?",
    options2: [
      "The checkout button should take the user to checkout page",
      "The grand total needs to be in local currency",
      "All the extra letters and numbers should be removed",
      "The font-size should be larger",
    ],
    correct2: "All the extra letters and numbers should be removed",
    hint: "Focus on the letter after the product names",
  },
  thirteenth: {
    question1: "What type of issue is it?",
    options1: ["Functional", "Visual", "Content", "Performance", "Crash"],
    correct1: "Content",
    question2: "What should be the expected result?",
    options2: [
      "The text should be in English language",
      "The text should be aligned to in the center",
      "The font size should be same as the font of the product price",
      "Clicking on the description should translate it to English language",
    ],
    correct2: "The text should be in English language",
    hint: "What is the language of the whole website?",
  },
  fourteenth: {
    question1: "What type of issue is it?",
    options1: ["Functional", "Visual", "Content", "Performance", "Crash"],
    correct1: "Content",
    question2: "What should be the expected result?",
    options2: [
      "The text should be in English language",
      "Clicking on the color should change the color of the product",
      "The color variant spellings should be written as 'Orange' and 'Yellow' instead of 'Orang' and 'Yelow' respectively",
      "Clicking on the color name should add that color product to cart",
    ],
    correct2:
      "The color variant spellings should be written as 'Orange' and 'Yellow' instead of 'Orang' and 'Yelow' respectively",
    hint: "Focus on the spelling of the color names!",
  },
  fifteenth: {
    question1: "What type of issue is it?",
    options1: ["Functional", "Visual", "Content", "Performance", "Crash"],
    correct1: "Content",
    question2: "What should be the expected result?",
    options2: [
      "The text should be in English language",
      "The caption of the 'Return to Store' button is written with proper spacing between letters",
      "The button should take the user to homepage",
      "Clicking on 'Return to Store' button should take us to the store page",
    ],
    correct2:
      "The caption of the 'Return to Store' button is written with proper spacing between letters",
    hint: "Check for the spacing between each letter",
  },
  sixteenth: {
    question1: "What type of issue is it?",
    options1: ["Functional", "Visual", "Content", "Performance", "Crash"],
    correct1: "Performance",
    question2: "What should be the expected result?",
    options2: [
      "Billing information should be updated after filling out the form and clicking 'Update'",
      "User should be redirected to the home page after clicking on 'Update'",
      "Billing info should be reset if it keeps on loading due to slow internet",
      "User should see the warning message for entering fake billing details",
    ],
    correct2:
      "Billing information should be updated after filling out the form and clicking 'Update'",
    hint: "Check if the billing information is saved successfully or not",
  },
  seventeenth: {
    question1: "What type of issue is it?",
    options1: ["Functional", "Visual", "Content", "Performance", "Crash"],
    correct1: "Performance",
    question2: "What should be the expected result?",
    options2: [
      "Your Order History section shows appropriate info",
      "User should be redirected to the home page if there is not order in the order history",
      "User should be shown attractive products if there is not orders in the order history",
      "User should see a message informing them to buy a product or their account will be deleted",
    ],
    correct2: "Your Order History section shows appropriate info",
    hint: "Check if the Order History has properly loaded or not",
  },
  eighteenth: {
    question1: "What type of issue is it?",
    options1: ["Functional", "Visual", "Content", "Performance", "Crash"],
    correct1: "Performance",
    question2: "What should be the expected result?",
    options2: [
      "The Billing Address section should also show shipping address",
      "The Billing Address section shows appropriate info",
      "The billing address should also show the payment details",
      "User should see a message informing them to save a real billing address otherwise their account will be deleted",
    ],
    correct2: "The Billing Address section shows appropriate info",
    hint: "Check if the Billing Address section has properly loaded or not",
  },
  nineteenth: {
    question1: "What type of issue is it?",
    options1: ["Functional", "Visual", "Content", "Performance", "Crash"],
    correct1: "Performance",
    question2: "What should be the expected result?",
    options2: [
      "The product page should say the item is not in stock",
      "The product in the Hot Item section is properly loaded and displayed",
      "User should be redirected to homepage",
      "User should get a discount on the item since it is not loading on time",
    ],
    correct2:
      "The product in the Hot Item section is properly loaded and displayed",
    hint: "Is the page fully loaded?",
  },
  twentieth: {
    question1: "What type of issue is it?",
    options1: ["Functional", "Visual", "Content", "Performance", "Crash"],
    correct1: "Performance",
    question2: "What should be the expected result?",
    options2: [
      "It should show a warning saying myspace is not available",
      "It should be written as 'Loading' instead of 'Please Wait'",
      "The user is able to share the product through My Space",
      "Clicking on My space icon should instantly share it on My Space",
    ],
    correct2: "The user is able to share the product through My Space",
    hint: "What is happening when you click on the My Space share icon?",
  },
  twentySecond: {
    question1: "What type of issue is it?",
    options1: ["Functional", "Visual", "Content", "Performance", "Crash"],
    correct1: "Crash",
    question2: "What should be the expected result?",
    options2: [
      "The font size should be bigger",
      "The products which have enough number of items in stock should be shown",
      "The page should show only 5 results on single page",
      "The selected number of results is displayed according to the clicked buttons",
    ],
    correct2:
      "The selected number of results is displayed according to the clicked buttons",
    hint: "What should happen when you clicked on 'View Number of results per page'?",
  },
  twentyThird: {
    question1: "What type of issue is it?",
    options1: ["Functional", "Visual", "Content", "Performance", "Crash"],
    correct1: "Crash",
    question2: "What should be the expected result?",
    options2: [
      "The comment is posted under the product",
      "The page should be refreshed automatically since it was crashed",
      "User should be able to post the comment when trying for the second time",
      "User should be shown a proper crash page",
    ],
    correct2: "The comment is posted under the product",
    hint: "What exactly happened when you tried posting a comment",
  },
};

// my new code is above here

jQuery(document).on("click", "div", function (e) {
  if (window.location.href.includes("https://academybugs.com/store")) {
    if (
      (jQuery(this).hasClass("ec_details_description") &&
        jQuery(this).hasClass("academy-bug")) ||
      (jQuery(this).hasClass("ec_details_description_content") &&
        jQuery(this).hasClass("academy-bug"))
    ) {
      e.preventDefault();

      if (isPopupOpen) return;
      isPopupOpen = true;
      // Add the highlight effect
      jQuery(this)
        .css("position", "relative")
        .append(
          '<div class="side-menu-sign-in-button-highlight" ' +
            'style="position: absolute; top: -3px; left: -4px; ' +
            "height:" +
            (jQuery(this).outerHeight() + 6) +
            "px; " +
            "width:" +
            (jQuery(this).outerWidth() + 9) +
            'px; border: 3px solid red"></div>'
        );

      // Fade out the highlight
      jQuery(".side-menu-sign-in-button-highlight").fadeOut(1800, function () {
        jQuery(".side-menu-sign-in-button-highlight").remove();
      });

      // Add a 2-second delay, then fade in the popup gradually over 1.5 seconds
      setTimeout(() => {
        showBugPopup("thirteenth", jQuery(this));
        jQuery(document).on("click", "#close-popup", function () {
          isPopupOpen = false; // Unlock when popup is closed
        });
        jQuery(document).on("click", "#submit-popup", function () {
          isPopupOpen = false; // Unlock when submitting
        });
      }, 1200);
    }
  }
});

jQuery(document).on("click", ".ec_details_option_label_selected", function (e) {
  if (
    ["Yelow", "Orang"].indexOf(
      jQuery(".ec_details_option_label_selected").text()
    ) >= 0
  ) {
    e.preventDefault();

    if (isPopupOpen) return;
    isPopupOpen = true;
    // Add the highlight effect
    jQuery(this)
      .css("position", "relative")
      .append(
        '<div class="side-menu-sign-in-button-highlight" ' +
          'style="position: absolute; top: -3px; left: -4px; ' +
          "height:" +
          (jQuery(this).outerHeight() + 6) +
          "px; " +
          "width:" +
          (jQuery(this).outerWidth() + 9) +
          'px; border: 3px solid red"></div>'
      );

    // Fade out the highlight
    jQuery(".side-menu-sign-in-button-highlight").fadeOut(1800, function () {
      jQuery(".side-menu-sign-in-button-highlight").remove();
    });

    // Add a 2-second delay, then fade in the popup gradually over 1.5 seconds
    setTimeout(() => {
      showBugPopup("fourteenth", jQuery(this));
      jQuery(document).on("click", "#close-popup", function () {
        isPopupOpen = false; // Unlock when popup is closed
      });
      jQuery(document).on("click", "#submit-popup", function () {
        isPopupOpen = false; // Unlock when submitting
      });
    }, 1200);
  }
});

jQuery(document).on("click", "#ec_cart_total", function (e) {
  e.preventDefault();

  if (isPopupOpen) return;
  isPopupOpen = true;
  // Add the highlight effect
  jQuery(this)
    .css("position", "relative")
    .append(
      '<div class="side-menu-sign-in-button-highlight" ' +
        'style="position: absolute; top: -3px; left: -4px; ' +
        "height:" +
        (jQuery(this).outerHeight() + 6) +
        "px; " +
        "width:" +
        (jQuery(this).outerWidth() + 9) +
        'px; border: 3px solid red"></div>'
    );

  // Fade out the highlight
  jQuery(".side-menu-sign-in-button-highlight").fadeOut(1800, function () {
    jQuery(".side-menu-sign-in-button-highlight").remove();
  });

  // Add a 2-second delay, then fade in the popup gradually over 1.5 seconds
  setTimeout(() => {
    showBugPopup("second", jQuery(this));
    jQuery(document).on("click", "#close-popup", function () {
      isPopupOpen = false; // Unlock when popup is closed
    });
    jQuery(document).on("click", "#submit-popup", function () {
      isPopupOpen = false; // Unlock when submitting
    });
  }, 1200);
});
jQuery(document).on("click", ".login-password-label-bug.bug10", function (e) {
  e.preventDefault();
  if (isPopupOpen) return;
  isPopupOpen = true;
  // Add the highlight effect
  jQuery(this)
    .css("position", "relative")
    .append(
      '<div class="side-menu-sign-in-button-highlight" ' +
        'style="position: absolute; top: -3px; left: -4px; ' +
        "height:" +
        (jQuery(this).outerHeight() + 6) +
        "px; " +
        "width:" +
        (jQuery(this).outerWidth() + 9) +
        'px; border: 3px solid red"></div>'
    );

  // Fade out the highlight
  jQuery(".side-menu-sign-in-button-highlight").fadeOut(1800, function () {
    jQuery(".side-menu-sign-in-button-highlight").remove();
  });

  // Add a 2-second delay, then fade in the popup gradually over 1.5 seconds
  setTimeout(() => {
    showBugPopup("tenth", jQuery(this));
    jQuery(document).on("click", "#close-popup", function () {
      isPopupOpen = false; // Unlock when popup is closed
    });
    jQuery(document).on("click", "#submit-popup", function () {
      isPopupOpen = false; // Unlock when submitting
    });
  }, 1200);
});

function highlightElParent(el, top, left) {
  top = top === undefined ? 0 : top;
  left = left === undefined ? 0 : left;
  el.parent()
    .css("position", "relative")
    .append(
      '<div class="side-menu-sign-in-button-highlight" ' +
        'style="position: absolute; top: ' +
        top +
        "; left: " +
        left +
        "; " +
        "height:" +
        (el.outerHeight() + 12) +
        "px; " +
        "width:" +
        (el.outerWidth() + 12) +
        'px; border: 3px solid red"></div>'
    );
}
function highlightElItself(el, divClass) {
  divClass =
    divClass === undefined ? "side-menu-sign-in-button-highlight" : divClass;
  el.css("position", "relative").append(
    '<div class="' +
      divClass +
      '" ' +
      'style="position: absolute; top: 0; left: -4px; ' +
      "height:" +
      el.outerHeight() +
      "px; " +
      "width:" +
      el.outerWidth() +
      'px; border: 3px solid red"></div>'
  );
}

jQuery(document).on(
  "click",
  ".academy-bug.ec_cart_widget_minicart_product_title",
  function (e) {
    e.preventDefault();

    if (isPopupOpen) return;
    isPopupOpen = true; // Lock the function
    // Add the highlight effect
    jQuery(this)
      .css("position", "relative")
      .append(
        '<div class="side-menu-sign-in-button-highlight" ' +
          'style="position: absolute; top: -3px; left: -4px; ' +
          "height:" +
          (jQuery(this).outerHeight() + 6) +
          "px; " +
          "width:" +
          (jQuery(this).outerWidth() + 9) +
          'px; border: 3px solid red"></div>'
      );

    // Fade out the highlight
    jQuery(".side-menu-sign-in-button-highlight").fadeOut(1800, function () {
      jQuery(".side-menu-sign-in-button-highlight").remove();
    });

    // Add a 2-second delay, then fade in the popup gradually over 1.5 seconds
    setTimeout(() => {
      showBugPopup("twelfth", jQuery(this));
      jQuery(document).on("click", "#close-popup", function () {
        isPopupOpen = false; // Unlock when popup is closed
      });
      jQuery(document).on("click", "#submit-popup", function () {
        isPopupOpen = false; // Unlock when submitting
      });
    }, 1200);
  }
);

// ec_searchwidget-3
jQuery(document).on(
  "click",
  ".ec_account_subheader.untranslated-russian",
  function (e) {
    if (window.location.href.includes("https://academybugs.com/account")) {
      e.preventDefault();
      if (isPopupOpen) return;
      isPopupOpen = true;
      // Add the highlight effect
      jQuery(this)
        .css("position", "relative")
        .append(
          '<div class="side-menu-sign-in-button-highlight" ' +
            'style="position: absolute; top: -3px; left: -4px; ' +
            "height:" +
            (jQuery(this).outerHeight() + 6) +
            "px; " +
            "width:" +
            (jQuery(this).outerWidth() + 9) +
            'px; border: 3px solid red"></div>'
        );

      // Fade out the highlight
      jQuery(".side-menu-sign-in-button-highlight").fadeOut(1800, function () {
        jQuery(".side-menu-sign-in-button-highlight").remove();
      });

      // Add a 2-second delay, then fade in the popup gradually over 1.5 seconds
      setTimeout(() => {
        showBugPopup("eleventh", jQuery(this));
        jQuery(document).on("click", "#close-popup", function () {
          isPopupOpen = false; // Unlock when popup is closed
        });
        jQuery(document).on("click", "#submit-popup", function () {
          isPopupOpen = false; // Unlock when submitting
        });
      }, 1200);
    }
  }
);

jQuery(document).on(
  "click",
  ".ec_cart_billing_info_update_loader.academy-bug, .ec_cart_billing_info_update_loader.academy-bug-mobile",
  function (e) {
    if (
      window.location.href.includes(
        "https://academybugs.com/account/?ec_page=billing_information"
      )
    ) {
      e.preventDefault();
      if (isPopupOpen) return;
      isPopupOpen = true;
      highlightElParent(jQuery(this), -3, -4);

      // Fade out the highlight
      jQuery(".side-menu-sign-in-button-highlight").fadeOut(1800, function () {
        jQuery(".side-menu-sign-in-button-highlight").remove();
      });

      // Add a 2-second delay, then fade in the popup gradually over 1.5 seconds
      setTimeout(() => {
        showBugPopup("sixteenth", jQuery(this));
        jQuery(document).on("click", "#close-popup", function () {
          isPopupOpen = false; // Unlock when popup is closed
        });
        jQuery(document).on("click", "#submit-popup", function () {
          isPopupOpen = false; // Unlock when submitting
        });
      }, 1200);
    }
  }
);

jQuery(document).on(
  "click",
  ".ec_cart_billing_info_update_loader.academy-bug17",
  function (e) {
    if (
      window.location.href.includes(
        "https://academybugs.com/account/?ec_page=orders"
      )
    ) {
      e.preventDefault();
      if (isPopupOpen) return;
      isPopupOpen = true;
      // Add the highlight effect
      jQuery(this)
        .parent()
        .css("position", "relative")
        .append(
          '<div class="side-menu-sign-in-button-highlight" ' +
            'style="position: absolute; top: 12px; left: 0px; ' +
            "height:" +
            (jQuery(this).outerHeight() + 14) +
            "px; " +
            "width:" +
            (jQuery(this).outerWidth() + 14) +
            'px; border: 3px solid red"></div>'
        );

      // Fade out the highlight
      jQuery(".side-menu-sign-in-button-highlight").fadeOut(1800, function () {
        jQuery(".side-menu-sign-in-button-highlight").remove();
      });

      // Add a 2-second delay, then fade in the popup gradually over 1.5 seconds
      setTimeout(() => {
        showBugPopup("seventeenth", jQuery(this));
        jQuery(document).on("click", "#close-popup", function () {
          isPopupOpen = false; // Unlock when popup is closed
        });
        jQuery(document).on("click", "#submit-popup", function () {
          isPopupOpen = false; // Unlock when submitting
        });
      }, 1200);
    }
  }
);

jQuery(document).on(
  "click",
  ".ec_cart_billing_info_update_loader.academy-bug-18",
  function (e) {
    if (window.location.href.includes("https://academybugs.com/account")) {
      e.preventDefault();
      if (isPopupOpen) return;
      isPopupOpen = true;
      // Add the highlight effect
      jQuery(this)
        .parent()
        .css("position", "relative")
        .append(
          '<div class="side-menu-sign-in-button-highlight" ' +
            'style="position: absolute; top: 6px; left: 0px; ' +
            "height:" +
            (jQuery(this).outerHeight() + 14) +
            "px; " +
            "width:" +
            (jQuery(this).outerWidth() + 14) +
            'px; border: 3px solid red"></div>'
        );

      // Fade out the highlight
      jQuery(".side-menu-sign-in-button-highlight").fadeOut(1800, function () {
        jQuery(".side-menu-sign-in-button-highlight").remove();
      });

      // Add a 2-second delay, then fade in the popup gradually over 1.5 seconds
      setTimeout(() => {
        showBugPopup("eighteenth", jQuery(this));
        jQuery(document).on("click", "#close-popup", function () {
          isPopupOpen = false; // Unlock when popup is closed
        });
        jQuery(document).on("click", "#submit-popup", function () {
          isPopupOpen = false; // Unlock when submitting
        });
      }, 1200);
    }
  }
);

jQuery(document).on(
  "click",
  ".ec_cart_billing_info_update_loader.academy-bug-19",
  function (e) {
    if (
      window.location.href.includes("https://academybugs.com/anchor-bracelet/")
    ) {
      e.preventDefault();
      if (isPopupOpen) return;
      isPopupOpen = true;
      // Add the highlight effect
      jQuery(this)
        .parent()
        .css("position", "relative")
        .append(
          '<div class="side-menu-sign-in-button-highlight" ' +
            'style="position: absolute; top: 12px; left: 0px; ' +
            "height:" +
            (jQuery(this).outerHeight() + 14) +
            "px; " +
            "width:" +
            (jQuery(this).outerWidth() + 14) +
            'px; border: 3px solid red"></div>'
        );

      // Fade out the highlight
      jQuery(".side-menu-sign-in-button-highlight").fadeOut(1800, function () {
        jQuery(".side-menu-sign-in-button-highlight").remove();
      });

      // Add a 2-second delay, then fade in the popup gradually over 1.5 seconds
      setTimeout(() => {
        showBugPopup("nineteenth", jQuery(this));
        jQuery(document).on("click", "#close-popup", function () {
          isPopupOpen = false; // Unlock when popup is closed
        });
        jQuery(document).on("click", "#submit-popup", function () {
          isPopupOpen = false; // Unlock when submitting
        });
      }, 1200);
    }
  }
);

jQuery(document).on("click", ".academy-bug-20", function (e) {
  if (window.location.href.includes("https://academybugs.com/myspace/")) {
    e.preventDefault();
    if (isPopupOpen) return;
    isPopupOpen = true;
    // Add the highlight effect
    jQuery(this)
      .parent()
      .css("position", "relative")
      .append(
        '<div class="side-menu-sign-in-button-highlight" ' +
          'style="position: absolute; top: -4px; left: -7px; ' +
          "height:" +
          (jQuery(this).outerHeight() + 14) +
          "px; " +
          "width:" +
          (jQuery(this).outerWidth() + 14) +
          'px; border: 3px solid red"></div>'
      );

    // Fade out the highlight
    jQuery(".side-menu-sign-in-button-highlight").fadeOut(1800, function () {
      jQuery(".side-menu-sign-in-button-highlight").remove();
    });

    // Add a 2-second delay, then fade in the popup gradually over 1.5 seconds
    setTimeout(() => {
      showBugPopup("twentieth", jQuery(this));
      jQuery(document).on("click", "#close-popup", function () {
        isPopupOpen = false; // Unlock when popup is closed
      });
      jQuery(document).on("click", "#submit-popup", function () {
        isPopupOpen = false; // Unlock when submitting
      });
    }, 1200);
  }
});

jQuery(document).on(
  "click",
  ".ec_login_widget_button.ec-widget-login",
  function (e) {
    e.preventDefault();
    if (isPopupOpen) return;
    isPopupOpen = true;
    // Add the highlight effect
    jQuery(this)
      .css("position", "relative")
      .append(
        '<div class="side-menu-sign-in-button-highlight" ' +
          'style="position: absolute; top: -6px; left: -6px; ' +
          "height:" +
          (jQuery(this).outerHeight() + 14) +
          "px; " +
          "width:" +
          (jQuery(this).outerWidth() + 14) +
          'px; border: 3px solid red"></div>'
      );

    // Fade out the highlight
    jQuery(".side-menu-sign-in-button-highlight").fadeOut(1800, function () {
      jQuery(".side-menu-sign-in-button-highlight").remove();
    });

    // Add a 2-second delay, then fade in the popup gradually over 1.5 seconds
    setTimeout(() => {
      showBugPopup("ninth", jQuery(this));
      jQuery(document).on("click", "#close-popup", function () {
        isPopupOpen = false; // Unlock when popup is closed
      });
      jQuery(document).on("click", "#submit-popup", function () {
        isPopupOpen = false; // Unlock when submitting
      });
    }, 1200);
  }
);

function clearPopupAssetsFor(pageType) {
  var selectors = {
    example: [".example-popup-bug-gif img", ".example-popup-bug-image img"],
    "types-of-bugs": [
      ".types-of-bugs-popup-gif img",
      ".types-of-bugs-popup-image img",
    ],
    "find-bugs": [".academy-popup-gif img", ".academy-popup-image-1 img"],
  };
  jQuery(selectors[pageType][0]).attr("src", "");
  jQuery(selectors[pageType][1]).attr("src", "");
}

function getLogIndex(fileUrl) {
  switch (fileUrl) {
    // bug 1
    case "https://academybugs.com/wp-content/uploads/2020/09/report-bug-1-log-4.log":
      return "1.log";
    case "https://academybugs.com/wp-content/uploads/2024/04/report-bug-1-log-1.txt":
      return "2.txt";
    case "https://academybugs.com/wp-content/uploads/2020/09/report-bug-1-log-2.docx":
      return "3.docx";
    // bug 2
    case "https://academybugs.com/wp-content/uploads/2020/09/report-bug-2-log-1.docx":
      return "1.docx";
    case "https://academybugs.com/wp-content/uploads/2020/09/report-bug-2-log-2.log":
      return "2.log";
    case "https://academybugs.com/wp-content/uploads/2020/09/report-bug-2-log-3.txt":
      return "3.txt";
    // bug 3
    case "https://academybugs.com/wp-content/uploads/2020/09/report-bug-3-log-1.log":
      return "1.log";
    case "https://academybugs.com/wp-content/uploads/2020/09/report-bug-3-log-3.txt":
      return "2.txt";
    case "https://academybugs.com/wp-content/uploads/2020/09/report-bug-3-log-2.docx":
      return "3.docx";
    // bug 4
    case "https://academybugs.com/wp-content/uploads/2020/09/report-bug-4-log-3.docx":
      return "1.docx";
    case "https://academybugs.com/wp-content/uploads/2020/09/report-bug-4-log-2.log":
      return "2.log";
    case "https://academybugs.com/wp-content/uploads/2020/09/report-bug-4-log-1.txt":
      return "3.txt";
    // bug 5
    case "https://academybugs.com/wp-content/uploads/2020/09/report-bug-5-log-1.docx":
      return "1.docx";
    case "https://academybugs.com/wp-content/uploads/2020/09/report-bug-5-log-2.log":
      return "2.log";
    case "https://academybugs.com/wp-content/uploads/2020/09/report-bug-5-log-3.txt":
      return "3.txt";
    default:
      break;
  }
}

function updateBugReportAttachment(attachmentType, bugIndex, fileSrc) {
  switch (attachmentType) {
    case "image":
      jQuery(".report-bugs-chosen-image-" + bugIndex).attr("src", fileSrc);
      break;
    case "video":
      jQuery(".report-bugs-chosen-video-" + bugIndex).attr("src", fileSrc);
      jQuery(".report-bugs-chosen-video-" + bugIndex)
        .parent()[0]
        .load();
      break;
    case "log":
      jQuery(".log-extension-" + bugIndex).text(getLogIndex(fileSrc));
      jQuery(".report-bugs-chosen-log-" + bugIndex).attr(
        "src",
        "https://academybugs.com/wp-content/uploads/2020/09/default-file-icon-cropped.svg"
      );
      jQuery(".report-bugs-chosen-log-link-" + bugIndex).attr("href", fileSrc);
      break;
    default:
      break;
  }
}

jQuery(document).on("click", "a, button[type='button']", function (e) {
  if (
    [
      "submit-bug-report-1",
      "submit-bug-report-2",
      "submit-bug-report-3",
      "submit-bug-report-4",
      "submit-bug-report-5",
      "try-again-link-1",
      "try-again-link-2",
      "try-again-link-3",
      "try-again-link-4",
      "try-again-link-5",
    ].indexOf(jQuery(this).prop("id")) >= 0
  ) {
    e.preventDefault();
    var parsedContent = JSON.parse(localStorage.getItem("bug-report"));
    var bugIndex = jQuery(this).prop("id").substr(-1);
    delete parsedContent["" + bugIndex];
    localStorage.setItem("bug-report", JSON.stringify(parsedContent));
    showInitialReportForm(bugIndex);
    window.scrollTo(0, 0);
  }
});

function showSubmitIssueSpinner(bugIndex, enabled) {
  if (enabled) {
    jQuery("#submit-bug-report-" + bugIndex + " .submit-issue-button-span").css(
      "margin-left",
      "8px"
    );
    jQuery("#submit-bug-report-" + bugIndex + " .spinner-border").css(
      "display",
      "inline-block"
    );
  } else {
    jQuery("#submit-bug-report-" + bugIndex + " .submit-issue-button-span").css(
      "margin-left",
      "0"
    );
    jQuery("#submit-bug-report-" + bugIndex + " .spinner-border").css(
      "display",
      "none"
    );
  }
}

function clearFieldsExcept(fieldName, bugIndex) {
  var fieldNames = [
    "bug-title-",
    "bug-type-",
    "frequency-",
    "priority-",
    "bug-step-",
    "expected-result-",
    "actual-result-",
    "error-message-",
    "image-",
    "video-",
    "log-",
  ];
  if (fieldName != "")
    fieldNames = fieldNames.filter(function (item) {
      return item !== fieldName;
    });
  for (let i = 0; i < fieldNames.length; i++) {
    const element = fieldNames[i];
    if (element == "bug-step-") {
      jQuery("#bug-" + bugIndex + "-sortable-1").css(
        "border",
        "1px solid #DDD"
      );
    } else if (["frequency-", "priority-"].indexOf(element) >= 0) {
      jQuery(
        "#" + element + "form-group-" + bugIndex + ">div>.report-bugs-error"
      ).css("display", "none");
      jQuery(
        "#" + element + "form-group-" + bugIndex + ">div>.radio-group-wrapper"
      ).css("border", "none");
    } else if (["image-", "video-", "log-"].indexOf(element) >= 0) {
      jQuery(
        "#" + element + "form-group-" + bugIndex + ">div>div>.report-bugs-error"
      ).css("display", "none");
      jQuery(
        "#" +
          element +
          "form-group-" +
          bugIndex +
          ">div>div>.radio-group-wrapper"
      ).css("border", "none");
    } else {
      jQuery('select[name="' + element + bugIndex + '"]')
        .next()
        .css("display", "none");
      jQuery('select[name="' + element + bugIndex + '"]').css(
        "border",
        "1px solid #DDD"
      );
    }
  }
}

function isReportBugFormValid(bugIndex) {
  var isValid = false;
  if (
    jQuery('select[name="bug-title-' + bugIndex + '"]')
      .find(":selected")
      .text() == "— Select the correct option —"
  ) {
    clearFieldsExcept("bug-title-", bugIndex);
    jQuery('select[name="bug-title-' + bugIndex + '"]')
      .next()
      .css("display", "block");
    jQuery('select[name="bug-title-' + bugIndex + '"]').css(
      "border",
      "1px solid #990000"
    );
    window.scrollTo(
      0,
      jQuery('select[name="bug-title-' + bugIndex + '"]').offset().top -
        jQuery('select[name="bug-title-' + bugIndex + '"]').outerHeight()
    );
  } else if (
    jQuery('select[name="bug-type-' + bugIndex + '"]')
      .find(":selected")
      .text() == "— Select the correct option —"
  ) {
    clearFieldsExcept("bug-type-", bugIndex);
    jQuery('select[name="bug-type-' + bugIndex + '"]')
      .next()
      .css("display", "block");
    jQuery('select[name="bug-type-' + bugIndex + '"]').css(
      "border",
      "1px solid #990000"
    );
    window.scrollTo(
      0,
      jQuery('select[name="bug-type-' + bugIndex + '"]').offset().top -
        jQuery('select[name="bug-type-' + bugIndex + '"]').outerHeight()
    );
  } else if (
    !jQuery('input[name="frequency-' + bugIndex + '"]').is(":checked")
  ) {
    clearFieldsExcept("frequency-", bugIndex);
    jQuery("#frequency-form-group-" + bugIndex + ">div>.report-bugs-error").css(
      "display",
      "block"
    );
    jQuery(
      "#frequency-form-group-" + bugIndex + ">div>.radio-group-wrapper"
    ).css("border", "1px solid #990000");
    window.scrollTo(
      0,
      jQuery("#frequency-form-group-" + bugIndex).offset().top -
        jQuery("#frequency-form-group-" + bugIndex).outerHeight()
    );
  } else if (
    !jQuery('input[name="priority-' + bugIndex + '"]').is(":checked")
  ) {
    clearFieldsExcept("priority-", bugIndex);
    jQuery("#priority-form-group-" + bugIndex + ">div>.report-bugs-error").css(
      "display",
      "block"
    );
    jQuery(
      "#priority-form-group-" + bugIndex + ">div>.radio-group-wrapper"
    ).css("border", "1px solid #990000");
    window.scrollTo(
      0,
      jQuery("#priority-form-group-" + bugIndex).offset().top -
        jQuery("#priority-form-group-" + bugIndex).outerHeight()
    );
  } else if (
    jQuery("#bug-" + bugIndex + "-sortable-1").children("li").length == 0
  ) {
    clearFieldsExcept("bug-step-", bugIndex);
    jQuery("#bug-" + bugIndex + "-sortable-1").css(
      "border",
      "1px solid #990000"
    );
    window.scrollTo(
      0,
      jQuery("#bug-" + bugIndex + "-sortable-1").offset().top -
        jQuery('select[name="bug-type-' + bugIndex + '"]').outerHeight()
    );
  } else if (
    jQuery('select[name="expected-result-' + bugIndex + '"]')
      .find(":selected")
      .text() == "— Select the correct option —"
  ) {
    clearFieldsExcept("expected-result-", bugIndex);
    jQuery('select[name="expected-result-' + bugIndex + '"]')
      .next()
      .css("display", "block");
    jQuery('select[name="expected-result-' + bugIndex + '"]').css(
      "border",
      "1px solid #990000"
    );
    window.scrollTo(
      0,
      jQuery('select[name="expected-result-' + bugIndex + '"]').offset().top -
        jQuery('select[name="expected-result-' + bugIndex + '"]').outerHeight()
    );
  } else if (
    jQuery('select[name="actual-result-' + bugIndex + '"]')
      .find(":selected")
      .text() == "— Select the correct option —"
  ) {
    clearFieldsExcept("actual-result-", bugIndex);
    jQuery('select[name="actual-result-' + bugIndex + '"]')
      .next()
      .css("display", "block");
    jQuery('select[name="actual-result-' + bugIndex + '"]').css(
      "border",
      "1px solid #990000"
    );
    window.scrollTo(
      0,
      jQuery('select[name="actual-result-' + bugIndex + '"]').offset().top -
        jQuery('select[name="actual-result-' + bugIndex + '"]').outerHeight()
    );
  } else if (
    jQuery('select[name="error-message-' + bugIndex + '"]')
      .find(":selected")
      .text() == "— Select the correct option —"
  ) {
    clearFieldsExcept("error-message-", bugIndex);
    jQuery('select[name="error-message-' + bugIndex + '"]')
      .next()
      .css("display", "block");
    jQuery('select[name="error-message-' + bugIndex + '"]').css(
      "border",
      "1px solid #990000"
    );
    window.scrollTo(
      0,
      jQuery('select[name="error-message-' + bugIndex + '"]').offset().top -
        jQuery('select[name="error-message-' + bugIndex + '"]').outerHeight()
    );
  } else if (!jQuery('input[name="image-' + bugIndex + '"]').is(":checked")) {
    clearFieldsExcept("image-", bugIndex);
    var imgselectWrapper = "#image-form-group-" + bugIndex + ">div>div>";
    jQuery(imgselectWrapper + ".report-bugs-error").css("display", "block");
    jQuery(imgselectWrapper + ".radio-group-wrapper").css(
      "border",
      "1px solid #990000"
    );
    window.scrollTo(
      0,
      jQuery(imgselectWrapper).offset().top -
        jQuery(imgselectWrapper).outerHeight() -
        10
    );
  } else if (!jQuery('input[name="video-' + bugIndex + '"]').is(":checked")) {
    var vSelectWrapper = "#video-form-group-" + bugIndex + ">div>div>";
    clearFieldsExcept("video-", bugIndex);
    jQuery(vSelectWrapper + ".report-bugs-error").css("display", "block");
    jQuery(vSelectWrapper + ".radio-group-wrapper").css(
      "border",
      "1px solid #990000"
    );
    window.scrollTo(
      0,
      jQuery(vSelectWrapper).offset().top -
        jQuery(vSelectWrapper).outerHeight() -
        10
    );
  } else if (!jQuery('input[name="log-' + bugIndex + '"]').is(":checked")) {
    var lSelectWrapper = "#log-form-group-" + bugIndex + ">div>div>";
    clearFieldsExcept("log-", bugIndex);
    jQuery(lSelectWrapper + ".report-bugs-error").css("display", "block");
    jQuery(lSelectWrapper + ".radio-group-wrapper").css(
      "border",
      "1px solid #990000"
    );
    window.scrollTo(
      0,
      jQuery(lSelectWrapper).offset().top -
        jQuery(lSelectWrapper).outerHeight() -
        10
    );
  } else {
    clearFieldsExcept("", bugIndex);
    isValid = true;
  }
  return isValid;
}

jQuery(document).on("submit", "form", function (e) {
  if (["commentform"].indexOf(jQuery(this).prop("id")) >= 0) {
    e.preventDefault();
    if (isPopupOpen) return;
    isPopupOpen = true;
    var wrapperDiv = jQuery("html");
    wrapperDiv.append(
      '<div class="academy-crash-overlay-bug" style="position:absolute;left:0;top:0; width:100%;height:' +
        jQuery("html").height() +
        'px;opacity:0;z-index:1000;background:#000;"></div>'
    );
    wrapperDiv.append(
      '<div class="academy-bug-info-overlay" ' +
        'style="background: rgba(0, 0, 0, 0.8); z-index: 100000; position: fixed; top: 0; left: 0; ' +
        "height:" +
        wrapperDiv.outerHeight() +
        "px; " +
        "width:" +
        wrapperDiv.outerWidth() +
        'px;">' +
        '<h5 style="text-align: center; color: white !important;' +
        'position: absolute; top: 200px; left: 50%; transform: translateX(-50%);">' +
        "You found a crash bug, examine the page by clicking on any button for 5 seconds.</h5>" +
        "</div>"
    );
    wait("3500", function () {
      jQuery(".academy-bug-info-overlay").fadeOut(700, function () {
        jQuery(".academy-bug-info-overlay").remove();
        jQuery(".academy-crash-overlay-bug").fadeOut(5000, function () {
          jQuery(".academy-crash-overlay-bug").remove();

          // Add a 2-second delay, then fade in the popup gradually over 1.5 seconds
          setTimeout(() => {
            showBugPopup("twentyThird", jQuery(this));
            jQuery(document).on("click", "#close-popup", function () {
              isPopupOpen = false; // Unlock when popup is closed
            });
            jQuery(document).on("click", "#submit-popup", function () {
              isPopupOpen = false; // Unlock when submitting
            });
          }, 200);
        });
      });
    });
  } else if (
    [
      "reportBugsForm1",
      "reportBugsForm2",
      "reportBugsForm3",
      "reportBugsForm4",
      "reportBugsForm5",
    ].indexOf(jQuery(this).prop("id")) >= 0
  ) {
    e.preventDefault();
    var currentBugIndex = jQuery(this).prop("id").substr(-1);
    var form = jQuery(e.target);
    const inputFields = form.find("input, textarea");
    inputFields.each(function () {
      const fieldName = jQuery(this).attr("name");
      const fieldValue = jQuery(this).val();
      console.log("Field Name:", fieldName);
      console.log("Field Value:", fieldValue);
    });
    if (isReportBugFormValid(currentBugIndex)) {
      showSubmitIssueSpinner(currentBugIndex, true);
      jQuery.ajax({
        type: "POST",
        url: "https://academybugs.com/wp-json/ac/v1/check-bug-report",
        data: form.serialize(), // serializes the form's elements.
        success: function (data) {
          if (localStorage.getItem("bug-report") == null) {
            localStorage.setItem("bug-report", data);
          } else {
            var localStorageData = JSON.parse(
              localStorage.getItem("bug-report")
            );
            var parsedData = JSON.parse(data);
            localStorageData["" + currentBugIndex] =
              parsedData["" + currentBugIndex];
            localStorage.setItem(
              "bug-report",
              JSON.stringify(localStorageData)
            );
          }
          showReportResult(currentBugIndex, data);
          showSubmitIssueSpinner(currentBugIndex, false);
        },
        error: function (request, status, error) {
          console.log("status: " + status + "; error: " + error);
        },
      });
    }
  }
});

function showInitialReportForm(bugIndex) {
  var bugReportForm = JSON.parse(localStorage.getItem("bug-report-form"));
  jQuery("#issue-title-form-group-" + bugIndex).html(
    bugReportForm[bugIndex]["issue-title"]
  );
  jQuery("#issue-type-form-group-" + bugIndex).html(
    bugReportForm[bugIndex]["issue-type"]
  );
  jQuery("#frequency-form-group-" + bugIndex).html(
    bugReportForm[bugIndex]["frequency"]
  );
  jQuery("#priority-form-group-" + bugIndex).html(
    bugReportForm[bugIndex]["priority"]
  );
  jQuery("#steps-form-group-" + bugIndex).html(
    bugReportForm[bugIndex]["steps"]
  );
  jQuery("#expected-result-form-group-" + bugIndex).html(
    bugReportForm[bugIndex]["expected-result"]
  );
  jQuery("#actual-result-form-group-" + bugIndex).html(
    bugReportForm[bugIndex]["actual-result"]
  );
  jQuery("#error-message-form-group-" + bugIndex).html(
    bugReportForm[bugIndex]["error-message"]
  );
  jQuery("#image-form-group-" + bugIndex).html(
    bugReportForm[bugIndex]["image"]
  );
  jQuery("#video-form-group-" + bugIndex).html(
    bugReportForm[bugIndex]["video"]
  );
  jQuery("#log-form-group-" + bugIndex).html(bugReportForm[bugIndex]["log"]);
  jQuery("#submit-bug-report-" + bugIndex).html(
    '<span class="spinner-border"></span><span class="submit-issue-button-span">Submit Issue</span>'
  );
  jQuery("#submit-bug-report-" + bugIndex).attr("type", "submit");
  showScoreCounter(false, bugIndex);
  if (window.innerWidth < 480) {
    jQuery(".selectpicker").append('<optgroup label=""></optgroup>');
  }
  handleSortable(bugIndex);
}

function preload(bugIndex) {
  var arrayOfImages = [
    [
      "https://academybugs.com/wp-content/uploads/2024/04/1-image-1.png",
      "https://academybugs.com/wp-content/uploads/2024/04/1-image-2.png",
      "https://academybugs.com/wp-content/uploads/2024/04/1-image-3.png",
    ],
    [
      "https://academybugs.com/wp-content/uploads/2020/10/2-image-1.png",
      "https://academybugs.com/wp-content/uploads/2024/04/2-image-2.png",
      "https://academybugs.com/wp-content/uploads/2020/10/2-image-3.png",
    ],
    [
      "https://academybugs.com/wp-content/uploads/2020/10/3-image-1.png",
      "https://academybugs.com/wp-content/uploads/2020/10/3-image-2.png",
      "https://academybugs.com/wp-content/uploads/2020/10/3-image-3.png",
    ],
    [
      "https://academybugs.com/wp-content/uploads/2020/10/4-image-1.png",
      "https://academybugs.com/wp-content/uploads/2020/10/4-image-2.png",
      "https://academybugs.com/wp-content/uploads/2020/10/4-image-3.png",
    ],
    [
      "https://academybugs.com/wp-content/uploads/2020/10/5-image-1.png",
      "https://academybugs.com/wp-content/uploads/2020/10/5-image-2.png",
      "https://academybugs.com/wp-content/uploads/2020/10/5-image-3.png",
    ],
  ];
  var currentImages = arrayOfImages[bugIndex - 1];
  jQuery(currentImages).each(function () {
    jQuery("<img />").attr("src", this).appendTo("body").css("display", "none");
  });
}

function buildBugReportFormObject(bugIndex) {
  var bugReportForm = {};
  bugReportForm[bugIndex] = {
    "issue-title": jQuery("#issue-title-form-group-" + bugIndex).html(),
    "issue-type": jQuery("#issue-type-form-group-" + bugIndex).html(),
    frequency: jQuery("#frequency-form-group-" + bugIndex).html(),
    priority: jQuery("#priority-form-group-" + bugIndex).html(),
    steps: jQuery("#steps-form-group-" + bugIndex).html(),
    "expected-result": jQuery("#expected-result-form-group-" + bugIndex).html(),
    "actual-result": jQuery("#actual-result-form-group-" + bugIndex).html(),
    "error-message": jQuery("#error-message-form-group-" + bugIndex).html(),
    image: jQuery("#image-form-group-" + bugIndex).html(),
    video: jQuery("#video-form-group-" + bugIndex).html(),
    log: jQuery("#log-form-group-" + bugIndex).html(),
  };
  return bugReportForm;
}

function storeBugReportForm(bugIndex) {
  if (localStorage.getItem("bug-report-form") == null) {
    var bugReportForm = buildBugReportFormObject(bugIndex);
    localStorage.setItem("bug-report-form", JSON.stringify(bugReportForm));
  } else {
    var localStorageData = JSON.parse(localStorage.getItem("bug-report-form"));
    if (localStorageData[bugIndex] == undefined) {
      var bugReportForm = buildBugReportFormObject(bugIndex);
      localStorageData[bugIndex] = bugReportForm[bugIndex];
      localStorage.setItem("bug-report-form", JSON.stringify(localStorageData));
    }
  }
}

function showReportResult(bugIndex, responseData) {
  jQuery("#issue-title-form-group-" + bugIndex).html(
    '<label class="control-label required" style="flex: 2"><h6><small><b>Issue Title</b></small>' +
      '<span><img width="19" class="mobile-grade-icon bug-title-' +
      bugIndex +
      '-grade-icon" src="" alt=""></span></h6></label>' +
      '<div style="flex: 9.3;">' +
      '<p id="bug-title-' +
      bugIndex +
      '" class="disabled-looking-text-field" style="">Test</p>' +
      '<div id="bug-title-' +
      bugIndex +
      '-right-answer" class="report-bugs-right-answer">' +
      '<h6 class="report-results-correct-answer-title"><small><b>Correct answer:</b></small></h6>' +
      "<p>Windows 10 - Home Page - Blank overlay when product image expanded</p>" +
      "</div></div>" +
      '<div style="flex: 1; text-align: right"><img class="pc-grade-icon bug-title-' +
      bugIndex +
      '-grade-icon" src="" alt=""></div>'
  );
  jQuery("#issue-type-form-group-" + bugIndex).html(
    '<label class="control-label required" style="flex: 2">' +
      "<h6><small><b>Type</b></small>" +
      '<span><img width="19" class="mobile-grade-icon bug-type-' +
      bugIndex +
      '-grade-icon" src="" alt=""></span></h6></label>' +
      '<div style="flex: 9.3;">' +
      '<p id="bug-type-' +
      bugIndex +
      '" class="disabled-looking-text-field" style="">Content</p>' +
      '<div id="bug-type-' +
      bugIndex +
      '-right-answer" class="report-bugs-right-answer">' +
      '<h6 class="report-results-correct-answer-title"><small><b>Correct answer:</b></small></h6>' +
      "<p>Content</p></div></div>" +
      '<div style="flex: 1; text-align: right"><img class="pc-grade-icon bug-type-' +
      bugIndex +
      '-grade-icon" src="" alt=""></div>'
  );
  jQuery("#frequency-form-group-" + bugIndex).html(
    '<label class="control-label required" style="flex: 2">' +
      "<h6><small><b>Frequency</b></small>" +
      '<span><img width="19" class="mobile-grade-icon frequency-' +
      bugIndex +
      '-grade-icon" src="" alt=""></span></h6></label>' +
      '<div class="btn-group bug-report-form-btn-group" data-toggle="buttons" style="flex: 9.3">' +
      '<label class="frequency-' +
      bugIndex +
      '-label bug-report-form-field-value">' +
      '<input type="radio" id="report-bugs-frequency" name="issueFrequency" value="1" onchange="">Every Time</label>' +
      '<div id="frequency-' +
      bugIndex +
      '-right-answer-div" class="report-bugs-right-answer">' +
      '<h6 class="report-results-correct-answer-title"><small><b>Correct answer:</b></small></h6>' +
      '<p class="frequency-' +
      bugIndex +
      '-right-answer">Content</p></div></div>' +
      '<div style="flex: 1; text-align: right"><img class="pc-grade-icon frequency-' +
      bugIndex +
      '-grade-icon" src="" alt=""></div>'
  );
  jQuery("#priority-form-group-" + bugIndex).html(
    '<label class="control-label required" style="flex: 2">' +
      "<h6><small><b>Priority</b></small>" +
      '<span><img width="19" class="mobile-grade-icon priority-' +
      bugIndex +
      '-grade-icon" src="" alt=""></span></h6></label>' +
      '<div class="btn-group bug-report-form-btn-group" data-toggle="buttons" style="flex: 9.3">' +
      '<label class="priority-' +
      bugIndex +
      '-label bug-report-form-field-value">' +
      '<input type="radio" id="report-bugs-priority" name="issuePriority" value="1" onchange="">' +
      "Low</label>" +
      '<div id="priority-' +
      bugIndex +
      '-right-answer-div" class="report-bugs-right-answer">' +
      '<h6 class="report-results-correct-answer-title"><small><b>Correct answer:</b></small></h6>' +
      '<p class="priority-' +
      bugIndex +
      '-right-answer">High</p>' +
      "</div></div>" +
      '<div style="flex: 1; text-align: right"><img class="pc-grade-icon priority-' +
      bugIndex +
      '-grade-icon" src="" alt=""></div>'
  );
  jQuery("#steps-form-group-" + bugIndex).html(
    '<textarea placeholder="1." class="form-control rounded-0" id="ActionPerformedId" rows="4" ' +
      'name="actionPerformed" value="" onchange="" oninput="" style="flex: 5; display: none"></textarea>' +
      '<label class="control-label required" style="flex: 2;">' +
      "<h6><small><b>Action Performed</b></small>" +
      '<span><img width="19" class="mobile-grade-icon steps-' +
      bugIndex +
      '-grade-icon" src="" alt=""></span></h6></label>' +
      '<div style="flex: 9.3">' +
      '<ul id="bug-' +
      bugIndex +
      '-steps" class="bulletless-list report-bugs-action-performed-ul" style="margin-left: 0"></ul>' +
      '<div id="bug-' +
      bugIndex +
      '-steps-right-answer" class="report-bugs-right-answer">' +
      '<h6 class="report-results-correct-answer-title"><small><b>Correct answer:</b></small></h6>' +
      '<ul class="bulletless-list report-bugs-action-performed-ul" style="margin: 15px 0"></ul>' +
      "</div></div>" +
      '<div style="flex: 1; text-align: right"><img class="pc-grade-icon steps-' +
      bugIndex +
      '-grade-icon" src="" alt=""></div>'
  );
  jQuery("#expected-result-form-group-" + bugIndex).html(
    '<label class="control-label required" style="flex: 2">' +
      "<h6><small><b>Expected Result</b></small>" +
      '<span><img width="19" class="mobile-grade-icon expected-result-' +
      bugIndex +
      '-grade-icon" src="" alt=""></span></h6></label>' +
      '<div style="flex: 9.3">' +
      '<p id="expected-result-' +
      bugIndex +
      '" class="disabled-looking-text-field" style="">' +
      "The image is broken</p>" +
      '<div id="expected-result-' +
      bugIndex +
      '-right-answer" class="report-bugs-right-answer">' +
      '<h6 class="report-results-correct-answer-title"><small><b>Correct answer:</b></small></h6>' +
      "<p>The image is broken</p>" +
      "</div></div>" +
      '<div style="flex: 1; text-align: right"><img class="pc-grade-icon expected-result-' +
      bugIndex +
      '-grade-icon" src="" alt=""></div>'
  );
  jQuery("#actual-result-form-group-" + bugIndex).html(
    '<label class="control-label required" style="flex: 2">' +
      "<h6><small><b>Actual Result</b></small>" +
      '<span><img width="19" class="mobile-grade-icon actual-result-' +
      bugIndex +
      '-grade-icon" src="" alt=""></span></h6></label>' +
      '<div style="flex: 9.3">' +
      '<p id="actual-result-' +
      bugIndex +
      '" class="disabled-looking-text-field" style="">' +
      "An expanded image of the product should be shown</p>" +
      '<div id="actual-result-' +
      bugIndex +
      '-right-answer" class="report-bugs-right-answer">' +
      '<h6 class="report-results-correct-answer-title"><small><b>Correct answer:</b></small></h6>' +
      "<p>An expanded image of the product should be shown</p>" +
      "</div></div>" +
      '<div style="flex: 1; text-align: right"><img class="pc-grade-icon actual-result-' +
      bugIndex +
      '-grade-icon" src="" alt=""></div>'
  );
  jQuery("#error-message-form-group-" + bugIndex).html(
    '<label class="control-label" style="flex: 2">' +
      "<h6><small><b>Error Message</b></small>" +
      '<span><img width="19" class="mobile-grade-icon error-message-' +
      bugIndex +
      '-grade-icon" src="" alt=""></span></h6></label>' +
      '<div style="flex: 9.3">' +
      '<p id="error-message-' +
      bugIndex +
      '" class="disabled-looking-text-field" style=""></p>' +
      '<div id="error-message-' +
      bugIndex +
      '-right-answer" class="report-bugs-right-answer">' +
      '<h6 class="report-results-correct-answer-title"><small><b>Correct answer:</b></small></h6>' +
      "<p></p>" +
      "</div></div>" +
      '<div style="flex: 1; text-align: right"><img class="pc-grade-icon error-message-' +
      bugIndex +
      '-grade-icon" src="" alt=""></div>'
  );
  jQuery("#image-form-group-" + bugIndex).html(
    '<h6 style="flex: 2"><small><b>Screenshot</b></small>' +
      '<span><img width="19" class="mobile-grade-icon image-' +
      bugIndex +
      '-grade-icon" src="" alt=""></span></h6>' +
      '<div style="flex: 8.7;">' +
      '<img id="image-' +
      bugIndex +
      '" class="report-bugs-chosen-image-' +
      bugIndex +
      '" src="https://academybugs.com/wp-content/uploads/2020/09/report-bug-5-image-1.png" alt="">' +
      '<div id="image-' +
      bugIndex +
      '-right-answer" class="report-bugs-right-answer">' +
      '<h6 class="report-results-correct-answer-title"><small><b>Correct answer:</b></small></h6>' +
      '<p><img class="report-bugs-chosen-image-' +
      bugIndex +
      '" src="https://academybugs.com/wp-content/uploads/2020/09/report-bug-5-image-1.png" alt=""></p>' +
      "</div></div>" +
      '<div style="flex: 1; text-align: right"><img class="pc-grade-icon image-' +
      bugIndex +
      '-grade-icon" src="" alt=""></div>'
  );
  jQuery("#video-form-group-" + bugIndex).html(
    '<h6 style="flex: 2"><small><b>Screen recording</b></small>' +
      '<span><img width="19" class="mobile-grade-icon video-' +
      bugIndex +
      '-grade-icon" src="" alt=""></span></h6>' +
      '<div style="flex: 8.7;">' +
      '<div style="margin: 0 auto 21px; width: 100%;">' +
      '<video width="100%" controls>' +
      '<source id="video-' +
      bugIndex +
      '" class="report-bugs-chosen-video-' +
      bugIndex +
      '" src="" ' +
      'type="video/mp4">Your browser does not support the video tag.' +
      "</video></div>" +
      '<div id="video-' +
      bugIndex +
      '-right-answer" class="report-bugs-right-answer">' +
      '<h6 class="report-results-correct-answer-title"><small><b>Correct answer:</b></small></h6>' +
      '<p><video width="100%" style="margin-top: 8px" controls>' +
      '<source class="report-bugs-chosen-video-' +
      bugIndex +
      '" src="" type="video/mp4">' +
      "Your browser does not support the video tag." +
      "</video></p></div></div>" +
      '<div style="flex: 1; text-align: right"><img class="pc-grade-icon video-' +
      bugIndex +
      '-grade-icon" src="" alt=""></div>'
  );
  jQuery("#log-form-group-" + bugIndex).html(
    '<h6 style="flex: 2"><small><b>Log</b></small>' +
      '<span><img width="19" class="mobile-grade-icon log-' +
      bugIndex +
      '-grade-icon" src="" alt=""></span></h6>' +
      '<div style="flex: 8.7">' +
      '<div style="width: 90px"><a id="log-' +
      bugIndex +
      '" class="report-bugs-chosen-log-link-' +
      bugIndex +
      '" ' +
      'href="https://academybugs.com/wp-content/uploads/2024/04/report-bug-1-log-1.txt" target="_blank" rel="noopener noreferrer">' +
      '<img class="report-bugs-chosen-log-' +
      bugIndex +
      '" src="https://academybugs.com/wp-content/uploads/2020/09/default-file-icon-cropped.svg" alt=""></a>' +
      '<span class="initial-log-extension" style="display: block; font-size: 14px"></span></div>' +
      '<div id="log-' +
      bugIndex +
      '-right-answer" class="report-bugs-right-answer">' +
      '<h6 class="report-results-correct-answer-title"><small><b>Correct answer:</b></small></h6>' +
      '<p><div style="width: 90px"><a class="report-bugs-chosen-log-link-' +
      bugIndex +
      '" ' +
      'href="https://academybugs.com/wp-content/uploads/2024/04/report-bug-1-log-1.txt" target="_blank" rel="noopener noreferrer">' +
      '<img class="report-bugs-chosen-log-' +
      bugIndex +
      '" src="https://academybugs.com/wp-content/uploads/2020/09/default-file-icon-cropped.svg" alt=""></a>' +
      '<span class="right-log-' +
      bugIndex +
      '-extension" style="display: block; font-size: 14px"></span></div></p></div></div>' +
      '<div style="flex: 1; text-align: right"><img class="pc-grade-icon log-' +
      bugIndex +
      '-grade-icon" src="" alt=""></div>'
  );
  var parsedContent = JSON.parse(responseData);
  fillResultForm(bugIndex, parsedContent["" + bugIndex]);
  jQuery("#submit-bug-report-" + bugIndex).attr("type", "button");
  jQuery("#submit-bug-report-" + bugIndex).text("Try Again");
  jQuery(".score-counter-" + bugIndex).text();
  window.scrollTo(0, 0);
}

function fillResultForm(bugIndex, parsedContent) {
  var scoreCounter = 0;
  jQuery("#bug-title-" + bugIndex).html(parsedContent["bug-title"][0]);
  if (parsedContent["bug-title"][1] != true) {
    jQuery("#bug-title-" + bugIndex + "-right-answer > p:nth-child(2)").html(
      parsedContent["bug-title"][1]
    );
    jQuery("#bug-title-" + bugIndex + "-right-answer").css("display", "block");
    jQuery(".bug-title-" + bugIndex + "-grade-icon").attr(
      "src",
      "https://academybugs.com/wp-content/uploads/2020/09/32px-Dark_Red_x.png"
    );
    jQuery(".bug-title-" + bugIndex + "-grade-icon").addClass("x-grade-icon");
  } else {
    scoreCounter++;
    jQuery(".bug-title-" + bugIndex + "-grade-icon").attr(
      "src",
      "https://academybugs.com/wp-content/uploads/2020/10/32Check.svg"
    );
  }
  jQuery("#bug-type-" + bugIndex).html(parsedContent["bug-type"][0]);
  if (parsedContent["bug-type"][1] != true) {
    jQuery("#bug-type-" + bugIndex + "-right-answer > p:nth-child(2)").html(
      parsedContent["bug-type"][1]
    );
    jQuery("#bug-type-" + bugIndex + "-right-answer").css("display", "block");
    jQuery(".bug-type-" + bugIndex + "-grade-icon").attr(
      "src",
      "https://academybugs.com/wp-content/uploads/2020/09/32px-Dark_Red_x.png"
    );
    jQuery(".bug-type-" + bugIndex + "-grade-icon").addClass("x-grade-icon");
  } else {
    scoreCounter++;
    jQuery(".bug-type-" + bugIndex + "-grade-icon").attr(
      "src",
      "https://academybugs.com/wp-content/uploads/2020/10/32Check.svg"
    );
  }
  jQuery(".frequency-" + bugIndex + "-label").html(
    parsedContent["frequency"][0]
  );
  if (parsedContent["frequency"][1] != true) {
    jQuery(".frequency-" + bugIndex + "-right-answer").html(
      parsedContent["frequency"][1]
    );
    jQuery("#frequency-" + bugIndex + "-right-answer-div").css(
      "display",
      "block"
    );
    jQuery(".frequency-" + bugIndex + "-grade-icon").attr(
      "src",
      "https://academybugs.com/wp-content/uploads/2020/09/32px-Dark_Red_x.png"
    );
    jQuery(".frequency-" + bugIndex + "-grade-icon").addClass("x-grade-icon");
  } else {
    scoreCounter++;
    jQuery(".frequency-" + bugIndex + "-grade-icon").attr(
      "src",
      "https://academybugs.com/wp-content/uploads/2020/10/32Check.svg"
    );
  }
  jQuery(".priority-" + bugIndex + "-label").html(parsedContent["priority"][0]);
  if (parsedContent["priority"][1] != true) {
    jQuery(".priority-" + bugIndex + "-right-answer").html(
      parsedContent["priority"][1]
    );
    jQuery("#priority-" + bugIndex + "-right-answer-div").css(
      "display",
      "block"
    );
    jQuery(".priority-" + bugIndex + "-grade-icon").attr(
      "src",
      "https://academybugs.com/wp-content/uploads/2020/09/32px-Dark_Red_x.png"
    );
    jQuery(".priority-" + bugIndex + "-grade-icon").addClass("x-grade-icon");
  } else {
    scoreCounter++;
    jQuery(".priority-" + bugIndex + "-grade-icon").attr(
      "src",
      "https://academybugs.com/wp-content/uploads/2020/10/32Check.svg"
    );
  }
  if (parsedContent["bug-steps-wrong"] == "") {
    const bugStepsRight = parsedContent["bug-steps-right"];
    for (let index = 0; index < bugStepsRight.length; index++) {
      const element = bugStepsRight[index];
      jQuery("#bug-" + bugIndex + "-steps").append(
        '<li class="step-li-' +
          bugIndex +
          '">' +
          (index + 1) +
          ". " +
          element +
          "</li>"
      );
    }
    scoreCounter++;
    jQuery(".steps-" + bugIndex + "-grade-icon").attr(
      "src",
      "https://academybugs.com/wp-content/uploads/2020/10/32Check.svg"
    );
  } else {
    var bugStepsWrong = parsedContent["bug-steps-wrong"].filter(Boolean);
    if (bugStepsWrong.length == 0) {
      jQuery("#bug-" + bugIndex + "-steps").append(
        '<li class="step-li-' + bugIndex + '">Empty</li>'
      );
    } else {
      for (let index = 0; index < bugStepsWrong.length; index++) {
        const element = bugStepsWrong[index];
        jQuery("#bug-" + bugIndex + "-steps").append(
          '<li class="step-li-' +
            bugIndex +
            '">' +
            (index + 1) +
            ". " +
            element +
            "</li>"
        );
      }
    }
    const bugStepsRight = parsedContent["bug-steps-right"];
    for (let index = 0; index < bugStepsRight.length; index++) {
      const element = bugStepsRight[index];
      jQuery("#bug-" + bugIndex + "-steps-right-answer ul").append(
        '<li class="step-li-' +
          bugIndex +
          '">' +
          (index + 1) +
          ". " +
          element +
          "</li>"
      );
    }
    jQuery("#bug-" + bugIndex + "-steps-right-answer").css("display", "block");
    jQuery(".steps-" + bugIndex + "-grade-icon").attr(
      "src",
      "https://academybugs.com/wp-content/uploads/2020/09/32px-Dark_Red_x.png"
    );
    jQuery(".steps-" + bugIndex + "-grade-icon").addClass("x-grade-icon");
  }
  jQuery("#expected-result-" + bugIndex).html(
    parsedContent["expected-result"][0]
  );
  if (parsedContent["expected-result"][1] != true) {
    jQuery(
      "#expected-result-" + bugIndex + "-right-answer > p:nth-child(2)"
    ).html(parsedContent["expected-result"][1]);
    jQuery("#expected-result-" + bugIndex + "-right-answer").css(
      "display",
      "block"
    );
    jQuery(".expected-result-" + bugIndex + "-grade-icon").attr(
      "src",
      "https://academybugs.com/wp-content/uploads/2020/09/32px-Dark_Red_x.png"
    );
    jQuery(".expected-result-" + bugIndex + "-grade-icon").addClass(
      "x-grade-icon"
    );
  } else {
    scoreCounter++;
    jQuery(".expected-result-" + bugIndex + "-grade-icon").attr(
      "src",
      "https://academybugs.com/wp-content/uploads/2020/10/32Check.svg"
    );
  }
  jQuery("#actual-result-" + bugIndex).html(parsedContent["actual-result"][0]);
  if (parsedContent["actual-result"][1] != true) {
    jQuery(
      "#actual-result-" + bugIndex + "-right-answer > p:nth-child(2)"
    ).html(parsedContent["actual-result"][1]);
    jQuery("#actual-result-" + bugIndex + "-right-answer").css(
      "display",
      "block"
    );
    jQuery(".actual-result-" + bugIndex + "-grade-icon").attr(
      "src",
      "https://academybugs.com/wp-content/uploads/2020/09/32px-Dark_Red_x.png"
    );
    jQuery(".actual-result-" + bugIndex + "-grade-icon").addClass(
      "x-grade-icon"
    );
  } else {
    scoreCounter++;
    jQuery(".actual-result-" + bugIndex + "-grade-icon").attr(
      "src",
      "https://academybugs.com/wp-content/uploads/2020/10/32Check.svg"
    );
  }
  jQuery("#error-message-" + bugIndex).html(parsedContent["error-message"][0]);
  if (parsedContent["error-message"][1] != true) {
    jQuery(
      "#error-message-" + bugIndex + "-right-answer > p:nth-child(2)"
    ).html(parsedContent["error-message"][1]);
    jQuery("#error-message-" + bugIndex + "-right-answer").css(
      "display",
      "block"
    );
    jQuery(".error-message-" + bugIndex + "-grade-icon").attr(
      "src",
      "https://academybugs.com/wp-content/uploads/2020/09/32px-Dark_Red_x.png"
    );
    jQuery(".error-message-" + bugIndex + "-grade-icon").addClass(
      "x-grade-icon"
    );
  } else {
    scoreCounter++;
    jQuery(".error-message-" + bugIndex + "-grade-icon").attr(
      "src",
      "https://academybugs.com/wp-content/uploads/2020/10/32Check.svg"
    );
  }
  jQuery("#image-" + bugIndex).attr("src", parsedContent["image"][0]);
  if (parsedContent["image"][1] != true) {
    jQuery("#image-" + bugIndex + "-right-answer > p:nth-child(2) img").attr(
      "src",
      parsedContent["image"][1]
    );
    jQuery("#image-" + bugIndex + "-right-answer").css("display", "block");
    jQuery(".image-" + bugIndex + "-grade-icon").attr(
      "src",
      "https://academybugs.com/wp-content/uploads/2020/09/32px-Dark_Red_x.png"
    );
    jQuery(".image-" + bugIndex + "-grade-icon").addClass("x-grade-icon");
  } else {
    scoreCounter++;
    jQuery(".image-" + bugIndex + "-grade-icon").attr(
      "src",
      "https://academybugs.com/wp-content/uploads/2020/10/32Check.svg"
    );
  }
  jQuery("#video-" + bugIndex).attr("src", parsedContent["video"][0]);
  jQuery("#video-" + bugIndex)
    .parent()[0]
    .load();
  if (parsedContent["video"][1] != true) {
    jQuery(
      "#video-" + bugIndex + "-right-answer > p:nth-child(2) > video > source"
    ).attr("src", parsedContent["video"][1]);
    jQuery(
      "#video-" + bugIndex + "-right-answer > p:nth-child(2) > video"
    )[0].load();
    jQuery("#video-" + bugIndex + "-right-answer").css("display", "block");
    jQuery(".video-" + bugIndex + "-grade-icon").attr(
      "src",
      "https://academybugs.com/wp-content/uploads/2020/09/32px-Dark_Red_x.png"
    );
    jQuery(".video-" + bugIndex + "-grade-icon").addClass("x-grade-icon");
  } else {
    scoreCounter++;
    jQuery(".video-" + bugIndex + "-grade-icon").attr(
      "src",
      "https://academybugs.com/wp-content/uploads/2020/10/32Check.svg"
    );
  }
  jQuery("#log-" + bugIndex).attr("href", parsedContent["log"][0]);
  jQuery(".initial-log-extension").text(getLogIndex(parsedContent["log"][0]));
  if (parsedContent["log"][1] != true) {
    jQuery("#log-" + bugIndex + "-right-answer > p:nth-child(2) a").attr(
      "href",
      parsedContent["log"][1]
    );
    jQuery("#log-" + bugIndex + "-right-answer").css("display", "block");
    jQuery(".right-log-" + bugIndex + "-extension").text(
      getLogIndex(parsedContent["log"][1])
    );
    jQuery(".log-" + bugIndex + "-grade-icon").attr(
      "src",
      "https://academybugs.com/wp-content/uploads/2020/09/32px-Dark_Red_x.png"
    );
    jQuery(".log-" + bugIndex + "-grade-icon").addClass("x-grade-icon");
  } else {
    scoreCounter++;
    jQuery(".log-" + bugIndex + "-grade-icon").attr(
      "src",
      "https://academybugs.com/wp-content/uploads/2020/10/32Check.svg"
    );
  }
  jQuery(".score-counter-" + bugIndex).text(scoreCounter);
  storeScoreCounter(bugIndex, scoreCounter);
  showScoreCounter(true, bugIndex);
  enableTabsIfScoreCounterExists(bugIndex);
}

function enableTabsIfScoreCounterExists(bugIndex) {
  if (bugIndex == "all") {
    for (let i = 1; i < 5; i++) {
      if (ifScoreCounterExists(i)) {
        jQuery(".nav.nav-tabs")
          .children()
          .eq(i)
          .children(":first-child")
          .removeClass("disabled");
      } else {
        for (let j = i; j < 5; j++) {
          jQuery(".nav.nav-tabs")
            .children()
            .eq(j)
            .children(":first-child")
            .addClass("disabled");
        }
        break;
      }
    }
  } else {
    if (ifScoreCounterExists(bugIndex))
      jQuery(".nav.nav-tabs")
        .children()
        .eq(bugIndex)
        .children(":first-child")
        .removeClass("disabled");
    else
      jQuery(".nav.nav-tabs")
        .children()
        .eq(bugIndex)
        .children(":first-child")
        .addClass("disabled");
  }
}

function ifScoreCounterExists(bugIndex) {
  var localStorageVal = localStorage.getItem("score-counter");
  if (localStorageVal == null) return false;
  var parsedScoreCounterMap = JSON.parse(localStorageVal);
  return parsedScoreCounterMap.hasOwnProperty(bugIndex);
}

function storeScoreCounter(bugIndex, scoreCounter) {
  if (scoreCounter < 11) return;
  var localStorageVal = localStorage.getItem("score-counter");
  if (localStorageVal == null) {
    var newScoreCounterMap = {};
    newScoreCounterMap[bugIndex] = scoreCounter;
    localStorage.setItem("score-counter", JSON.stringify(newScoreCounterMap));
  } else {
    var parsedScoreCounterMap = JSON.parse(localStorageVal);
    if (!parsedScoreCounterMap.hasOwnProperty(bugIndex)) {
      parsedScoreCounterMap[bugIndex] = scoreCounter;
      localStorage.setItem(
        "score-counter",
        JSON.stringify(parsedScoreCounterMap)
      );
    }
  }
}

function showScoreCounter(enable, currentBugIndex) {
  currentBugIndex = currentBugIndex === undefined ? 0 : currentBugIndex;
  if (enable) {
    if (jQuery(".score-counter-" + currentBugIndex).text().length) {
      jQuery(".practice-creating-bug-reports-subtitle").attr(
        "style",
        "display: none"
      );
      var scoreCounter = jQuery(".score-counter-" + currentBugIndex).text();
      var scoreCounterText = "";
      if (scoreCounter == 11) {
        scoreCounterText = "Excellent! You completed the bug report correctly.";
        if (currentBugIndex != 5)
          scoreCounterText += " Please move to the next bug report.";
      } else {
        scoreCounterText =
          "#" +
          currentBugIndex +
          ": You answered " +
          scoreCounter +
          " out of 11 correctly. Please " +
          '<a href="#" id="try-again-link-' +
          currentBugIndex +
          '" >try again</a>.';
      }
      jQuery(".score-counter-subtitle").html(scoreCounterText);
      jQuery(".score-counter-subtitle")
        .parent()
        .attr("style", "display: block");
    } else {
      jQuery(".score-counter-subtitle").parent().attr("style", "display: none");
      jQuery(".practice-creating-bug-reports-subtitle").attr(
        "style",
        "display: block"
      );
    }
  } else {
    jQuery(".score-counter-" + currentBugIndex).text("");
    jQuery(".practice-creating-bug-reports-subtitle").attr(
      "style",
      "display: block"
    );
    jQuery(".score-counter-subtitle").parent().attr("style", "display: none");
  }
}

jQuery(document).on("change", "input", function (e) {
  // 1 bug
  if (jQuery(this).hasClass("reportBugImage")) {
    updateBugReportAttachment(
      "image",
      1,
      jQuery(
        "input.reportBugImage[name=image-1]:checked",
        "#reportBugsForm1"
      ).val()
    );
  }
  if (jQuery(this).hasClass("reportBugVideo")) {
    updateBugReportAttachment(
      "video",
      1,
      jQuery(
        "input.reportBugVideo[name=video-1]:checked",
        "#reportBugsForm1"
      ).val()
    );
  }
  if (jQuery(this).hasClass("reportBugLog")) {
    updateBugReportAttachment(
      "log",
      1,
      jQuery("input.reportBugLog[name=log-1]:checked", "#reportBugsForm1").val()
    );
  }
  // 2 bug
  if (jQuery(this).hasClass("reportBugImage2")) {
    updateBugReportAttachment(
      "image",
      2,
      jQuery(
        "input.reportBugImage2[name=image-2]:checked",
        "#reportBugsForm2"
      ).val()
    );
  }
  if (jQuery(this).hasClass("reportBugVideo2")) {
    updateBugReportAttachment(
      "video",
      2,
      jQuery(
        "input.reportBugVideo2[name=video-2]:checked",
        "#reportBugsForm2"
      ).val()
    );
  }
  if (jQuery(this).hasClass("reportBugLog2")) {
    updateBugReportAttachment(
      "log",
      2,
      jQuery(
        "input.reportBugLog2[name=log-2]:checked",
        "#reportBugsForm2"
      ).val()
    );
  }
  // 3 bug
  if (jQuery(this).hasClass("reportBugImage3")) {
    updateBugReportAttachment(
      "image",
      3,
      jQuery(
        "input.reportBugImage3[name=image-3]:checked",
        "#reportBugsForm3"
      ).val()
    );
  }
  if (jQuery(this).hasClass("reportBugVideo3")) {
    updateBugReportAttachment(
      "video",
      3,
      jQuery(
        "input.reportBugVideo3[name=video-3]:checked",
        "#reportBugsForm3"
      ).val()
    );
  }
  if (jQuery(this).hasClass("reportBugLog3")) {
    updateBugReportAttachment(
      "log",
      3,
      jQuery(
        "input.reportBugLog3[name=log-3]:checked",
        "#reportBugsForm3"
      ).val()
    );
  }
  // 4 bug
  if (jQuery(this).hasClass("reportBugImage4")) {
    updateBugReportAttachment(
      "image",
      4,
      jQuery(
        "input.reportBugImage4[name=image-4]:checked",
        "#reportBugsForm4"
      ).val()
    );
  }
  if (jQuery(this).hasClass("reportBugVideo4")) {
    updateBugReportAttachment(
      "video",
      4,
      jQuery(
        "input.reportBugVideo4[name=video-4]:checked",
        "#reportBugsForm4"
      ).val()
    );
  }
  if (jQuery(this).hasClass("reportBugLog4")) {
    updateBugReportAttachment(
      "log",
      4,
      jQuery(
        "input.reportBugLog4[name=log-4]:checked",
        "#reportBugsForm4"
      ).val()
    );
  }
  // 5 bug
  if (jQuery(this).hasClass("reportBugImage5")) {
    updateBugReportAttachment(
      "image",
      5,
      jQuery(
        "input.reportBugImage5[name=image-5]:checked",
        "#reportBugsForm5"
      ).val()
    );
  }
  if (jQuery(this).hasClass("reportBugVideo5")) {
    updateBugReportAttachment(
      "video",
      5,
      jQuery(
        "input.reportBugVideo5[name=video-5]:checked",
        "#reportBugsForm5"
      ).val()
    );
  }
  if (jQuery(this).hasClass("reportBugLog5")) {
    updateBugReportAttachment(
      "log",
      5,
      jQuery(
        "input.reportBugLog5[name=log-5]:checked",
        "#reportBugsForm5"
      ).val()
    );
  }
});

jQuery(document).on("click", ".report-bugs-modal-close", function (e) {
  jQuery("#my-report-bugs-modal").css("display", "none");
});

jQuery(document).on("click", "img", function (e) {
  if (
    jQuery(this).hasClass("report-bugs-chosen-image-1") ||
    jQuery(this).hasClass("report-bugs-chosen-image-2") ||
    jQuery(this).hasClass("report-bugs-chosen-image-3") ||
    jQuery(this).hasClass("report-bugs-chosen-image-4") ||
    jQuery(this).hasClass("report-bugs-chosen-image-5") ||
    jQuery(this).hasClass("academy_article_image")
  ) {
    jQuery("#my-report-bugs-modal").css("display", "block");
    jQuery("#img01").attr("src", jQuery(this).attr("src"));
    jQuery("#report-bugs-modal-caption").html(
      jQuery(
        "input.reportBugImage[name=bugImage]:checked",
        ".reportBugsForm"
      ).val()
    );
  }
});

jQuery(document).on("click", "input.academy-register-bug", function (e) {
  var academyRegisterBug = localStorage.getItem("academy-register-bug");
  if (academyRegisterBug == "enabled") {
    e.preventDefault();
    location = "https://academybugs.com/register-account/";
    localStorage.removeItem("academy-register-bug");
  }
});

function currentWindowWidth() {
  return (
    window.innerWidth ||
    document.documentElement.clientWidth ||
    document.body.clientWidth
  );
}

jQuery(document).on("click", "a", function (e) {
  if (jQuery(this).hasClass("nav-link") && !jQuery(this).hasClass("disabled")) {
    var currentScoreCounterText = jQuery(
      ".score-counter-" + jQuery(this).text()
    ).text();
    showScoreCounter(currentScoreCounterText.length > 0, jQuery(this).text());
    storeBugReportForm(jQuery(this).text());
    preload(parseInt(jQuery(this).text()));
  }
  /*  
        included in wp-easycart/.../ec_store.js in the ec_account_register_button_click2 function
        here it doesn't get executed since the link has an onClick handler which apparently doesn't allow for other handlers
    */
  // if (jQuery(this).hasClass('academy-checkout-bug')) {
  //     var academyCheckoutBug = localStorage.getItem("academy-checkout-bug");
  //     if (academyCheckoutBug != null) {
  //         if (academyCheckoutBug == "enabled") {
  //             e.preventDefault();
  //             var wrapperDiv = jQuery('body');
  //             wrapperDiv.append('<div class="academy-crash-overlay-bug" style="position:absolute;left:0;top:0; width:100%;height:' + jQuery('html').height() +
  //                 'px;opacity:0;z-index:1000;background:#000;"></div>');
  //             localStorage.removeItem("academy-checkout-bug");
  //         }
  //     }
  // }
  if (jQuery(this).hasClass("academy-popup-attachment-wrapper")) {
    e.preventDefault();
    jQuery(".report-bugs-image-file").attr("style", "display: none");
    jQuery(".report-bugs-chosen-image").attr({
      src: jQuery(this).find("img").attr("src"),
      style: "display: block; cursor: pointer",
    });
    jQuery(".pum-close.popmake-close").click();
  }
  if (jQuery(this).prop("id") == "academy-checkout-content-bug-link") {
    localStorage.setItem("academy-checkout-content-bug", "enabled");
  }
  if (jQuery(this).prop("id") == "academy-register-bug-link") {
    localStorage.setItem("academy-register-bug", "enabled");
  }
  if (jQuery(this).prop("id") == "academy-checkout-bug-link") {
    localStorage.setItem("academy-checkout-bug", "enabled");
  }
  if (jQuery(this).prop("id") == "academy-large-popup-image") {
    localStorage.setItem("academy-large-popup-image", "enabled");
  }
  if (jQuery(this).prop("id") == "academy-remove-product-from-cart-bug") {
    localStorage.setItem("remove-product-from-cart-bug", "enabled");
  }
  if (jQuery(this).hasClass("academy-tooltip-bug-link")) {
    var clickedBugIndex = jQuery(this)
      .attr("class")
      .replace("academy-tooltip-bug-link academy-tooltip-bug-", "");
    loadPopUpImageAndGif(clickedBugIndex);
    popupOpenAndCloseWithoutTitle(4406, function () {
      clearPopupAssetsFor("find-bugs");
    });
  }
  if (jQuery(this).hasClass("example-5-search-bug")) {
    e.preventDefault();
    var href = jQuery(this).attr("href");
    window.open(href + "?single");
  }
  if (jQuery(this).hasClass("types-of-bugs-tile-div")) {
    if (jQuery(this).is(":first-child")) {
      loadTypesPopup("functional");
      popupOpenAndCloseWithoutTitle(4454, function () {
        clearPopupAssetsFor("types-of-bugs");
      });
    }
    if (jQuery(this).is(":nth-child(2)")) {
      loadTypesPopup("visual");
      popupOpenAndCloseWithoutTitle(4454, function () {
        clearPopupAssetsFor("types-of-bugs");
      });
    }
    if (jQuery(this).is(":nth-child(3)")) {
      loadTypesPopup("content");
      popupOpenAndCloseWithoutTitle(4454, function () {
        clearPopupAssetsFor("types-of-bugs");
      });
    }
    if (jQuery(this).is(":nth-child(4)")) {
      loadTypesPopup("performance");
      popupOpenAndCloseWithoutTitle(4454, function () {
        clearPopupAssetsFor("types-of-bugs");
      });
    }
    if (jQuery(this).is(":nth-child(5)")) {
      loadTypesPopup("crash");
      popupOpenAndCloseWithoutTitle(4454, function () {
        clearPopupAssetsFor("types-of-bugs");
      });
    }
  }
  if (jQuery(this).hasClass("example-tile-div")) {
    if (jQuery(this).is(":first-child")) {
      loadExamplePopup(1);
      popupOpenAndCloseWithoutTitle(4434, function () {
        clearPopupAssetsFor("example");
      });
    }
    if (jQuery(this).is(":nth-child(2)")) {
      loadExamplePopup(2);
      popupOpenAndCloseWithoutTitle(4434, function () {
        clearPopupAssetsFor("example");
      });
    }
    if (jQuery(this).is(":nth-child(3)")) {
      loadExamplePopup(3);
      popupOpenAndCloseWithoutTitle(4434, function () {
        clearPopupAssetsFor("example");
      });
    }
    if (jQuery(this).is(":nth-child(4)")) {
      loadExamplePopup(4);
      popupOpenAndCloseWithoutTitle(4434, function () {
        clearPopupAssetsFor("example");
      });
    }
    if (jQuery(this).is(":nth-child(5)")) {
      loadExamplePopup(5);
      popupOpenAndCloseWithoutTitle(4434, function () {
        clearPopupAssetsFor("example");
      });
    }
    if (jQuery(this).is(":nth-child(6)")) {
      loadExamplePopup(6);
      popupOpenAndCloseWithoutTitle(4434, function () {
        clearPopupAssetsFor("example");
      });
    }
  }
  if (jQuery(this).hasClass("academy-store-menu-link")) {
    if (
      (window.location.href.includes("https://academybugs.com/store/") &&
        !window.location.href.includes(
          "https://academybugs.com/store/?perpage"
        ) &&
        window.location.href.length >
          "https://academybugs.com/store/".length) ||
      window.location.href.includes("https://academybugs.com/my-cart")
    ) {
      e.preventDefault();
      if (isPopupOpen) return;
      isPopupOpen = true;
      var href = jQuery(this).attr("href");
      localStorage.setItem("popupOpen", "fourth");
      // Add the highlight effect
      jQuery(this)
        .parent()
        .css("position", "relative")
        .append(
          '<div class="side-menu-sign-in-button-highlight" ' +
            'style="position: absolute; top: -6px; left: -7px; ' +
            "height:" +
            (jQuery(this).outerHeight() + 14) +
            "px; " +
            "width:" +
            (jQuery(this).outerWidth() + 14) +
            'px; border: 3px solid red"></div>'
        );
      jQuery(".side-menu-sign-in-button-highlight").fadeOut(1200, function () {
        jQuery(".side-menu-sign-in-button-highlight").remove();
      });

      if (jQuery(this).prop("target") === "_blank") window.open(href);
      else location = href;
    }
  }
  if (
    jQuery(this).parent().hasClass("ec_details_social_icon") &&
    jQuery(this).parent().hasClass("ec_twitter")
  ) {
    e.preventDefault();
    if (isPopupOpen) return;
    isPopupOpen = true;
    // Add the highlight effect
    jQuery(this)
      .parent()
      .parent()
      .css("position", "relative")
      .append(
        '<div class="side-menu-sign-in-button-highlight" ' +
          'style="position: absolute; top: -2px; left: 37px; ' +
          "height:" +
          (jQuery(this).outerHeight() + 4) +
          "px; " +
          "width:" +
          (jQuery(this).outerWidth() + 4) +
          'px; border: 3px solid red"></div>'
      );

    // Fade out the highlight
    jQuery(".side-menu-sign-in-button-highlight").fadeOut(1200, function () {
      jQuery(".side-menu-sign-in-button-highlight").remove();

      // Open a new page in a new tab
      window.open(
        "https://twitter.cointent/tweet?original_referer=#",
        "_blank"
      );
    });

    // Add a 2-second delay, then fade in the popup gradually over 1.5 seconds
    setTimeout(() => {
      showBugPopup("fifth", jQuery(this));
      jQuery(document).on("click", "#close-popup", function () {
        isPopupOpen = false; // Unlock when popup is closed
      });
      jQuery(document).on("click", "#submit-popup", function () {
        isPopupOpen = false; // Unlock when submitting
      });
    }, 1800);
  }
  if (jQuery(this).parent().prop("id") == "ec_product_image_effect_3481370") {
    var checkoutContentBug = localStorage.getItem(
      "academy-checkout-content-bug"
    );
    if (checkoutContentBug != undefined) {
      e.preventDefault();
      location = "https://academybugs.com/store/blue-tshirt?single";
      localStorage.removeItem("academy-checkout-content-bug");
    }
  }
  // Academy Bug 6
  if (jQuery(this).parent().prop("id") == "ec_product_image_effect_4281370") {
    if (window.location.href.includes("https://academybugs.com/find-bugs/")) {
      e.preventDefault();
      if (isPopupOpen) return;
      isPopupOpen = true;
      jQuery(this)
        .parent()
        .parent()
        .css("position", "relative")
        .append(
          '<div class="side-menu-sign-in-button-highlight" ' +
            'style="position: absolute; top: -4px; left: -2px; ' +
            "height:" +
            (jQuery(this).outerHeight() + 6) +
            "px; " +
            "width:" +
            (jQuery(this).outerWidth() + 6) +
            'px; border: 3px solid red"></div>'
        );

      // Fade out the highlight
      jQuery(".side-menu-sign-in-button-highlight").fadeOut(1800, function () {
        jQuery(".side-menu-sign-in-button-highlight").remove();
      });

      // Add a 2-second delay, then fade in the popup gradually over 1.5 seconds
      setTimeout(() => {
        showBugPopup("sixth", jQuery(this));
        jQuery(document).on("click", "#close-popup", function () {
          isPopupOpen = false; // Unlock when popup is closed
        });
        jQuery(document).on("click", "#submit-popup", function () {
          isPopupOpen = false; // Unlock when submitting
        });
      }, 1800);
    }
  }
  if (
    jQuery(this).parent().hasClass("ec_image_container_none") &&
    jQuery(this).parent().hasClass("ec_dynamic_image_height") &&
    jQuery(this).parent().prop("id") != "ec_product_image_effect_SKU0555" &&
    jQuery(this).parent().prop("id") != "ec_product_image_effect_SKU3425" &&
    jQuery(this).parent().prop("id") != "ec_product_image_effect_SKU7505"
  ) {
    if (
      window.location.href.includes("https://academybugs.com/store/all-items/")
    ) {
      e.preventDefault();
      if (isPopupOpen) return;
      isPopupOpen = true;
      var href = jQuery(this).attr("href");
      // Add the highlight effect
      jQuery(this)
        .parent()
        .parent()
        .parent()
        .css("position", "relative")
        .append(
          '<div class="side-menu-sign-in-button-highlight" ' +
            'style="position: absolute; top: -2px; left: 25px; ' +
            "height:" +
            (jQuery(this).outerHeight() + 4) +
            "px; " +
            "width:" +
            (jQuery(this).outerWidth() + 4) +
            'px; border: 3px solid red"></div>'
        );

      // Fade out the highlight
      jQuery(".side-menu-sign-in-button-highlight").fadeOut(1800, function () {
        jQuery(".side-menu-sign-in-button-highlight").remove();
      });

      // Add a 2-second delay, then fade in the popup gradually over 1.5 seconds
      setTimeout(() => {
        showBugPopup("eighth", jQuery(this));
        jQuery(document).on("click", "#close-popup", function () {
          isPopupOpen = false; // Unlock when popup is closed
        });
        jQuery(document).on("click", "#submit-popup", function () {
          isPopupOpen = false; // Unlock when submitting
        });
      }, 1200);
    }
  }
  if (
    jQuery(this).hasClass("ec_cart_empty_button") &&
    jQuery(this).hasClass("academy-bug")
  ) {
    e.preventDefault();
    var href = jQuery(this).attr("href");
    if (isPopupOpen) return;
    isPopupOpen = true;
    // Add the highlight effect
    jQuery(this)
      .css("position", "relative")
      .append(
        '<div class="side-menu-sign-in-button-highlight" ' +
          'style="position: absolute; top: -6px; left: -7px; ' +
          "height:" +
          (jQuery(this).outerHeight() + 14) +
          "px; " +
          "width:" +
          (jQuery(this).outerWidth() + 14) +
          'px; border: 3px solid red"></div>'
      );

    // Fade out the highlight
    jQuery(".side-menu-sign-in-button-highlight").fadeOut(1800, function () {
      jQuery(".side-menu-sign-in-button-highlight").remove();
    });

    // Add a 2-second delay, then fade in the popup gradually over 1.5 seconds
    setTimeout(() => {
      showBugPopup("fifteenth", jQuery(this));
      jQuery(document).on("click", "#close-popup", function () {
        isPopupOpen = false; // Unlock when popup is closed
      });
      jQuery(document).on("click", "#submit-popup", function () {
        isPopupOpen = false; // Unlock when submitting
      });
    }, 1200);
  }

  if (jQuery(this).prop("class") == "what-we-offer-pagination-link") {
    var wrapperDiv = jQuery("body");
    wrapperDiv.append(
      '<div class="academy-crash-overlay-bug" style="position:absolute;left:0;top:0; width:100%;height:' +
        jQuery(document).outerHeight() +
        'px;opacity:0;z-index:1000;background:#000;"></div>'
    );
    if (
      window.location.href.indexOf("https://academybugs.com/what-we-offer/") ===
      -1
    ) {
      wrapperDiv.append(
        '<div class="academy-bug-overlay" ' +
          'style="background: rgba(0, 0, 0, 0.8); z-index: 100000; position: fixed; top: 0; left: 0; ' +
          "height:" +
          wrapperDiv.outerHeight() +
          "px; " +
          "width:" +
          wrapperDiv.outerWidth() +
          'px;">' +
          '<h5 style="text-align: center; color: white !important;' +
          'position: absolute; top: 200px; left: 50%; transform: translateX(-50%);">' +
          "You found a crash bug, examine the page by clicking on any button for 5 seconds.</h5>" +
          "</div>"
      );
      wait("3500", function () {
        jQuery(".academy-bug-overlay").fadeOut(700, function () {
          jQuery(".academy-bug-overlay").remove();
          jQuery(".academy-crash-overlay-bug").fadeOut(5000, function () {
            jQuery(".academy-crash-overlay-bug").remove();

            // Add a 2-second delay, then fade in the popup gradually over 1.5 seconds
            setTimeout(() => {
              showBugPopup("twentySecond", jQuery(this));
              jQuery(document).on("click", "#close-popup", function () {
                isPopupOpen = false; // Unlock when popup is closed
              });
              jQuery(document).on("click", "#submit-popup", function () {
                isPopupOpen = false; // Unlock when submitting
              });
            }, 200);
          });
        });
      });
    }
  }
  if (jQuery(this).parent().prop("id") == "manufacturer-bug") {
    e.preventDefault();
    var href = jQuery(this).attr("href");

    localStorage.setItem("manufacturer-bug", "1");
    // Store the current page URL in sessionStorage to return later
    sessionStorage.setItem("previous-page", window.location.href);
      
      if (jQuery(this).prop("target") === "_blank") window.open(href);
    else location = href;
   
     // After 5 seconds, automatically navigate back
    setTimeout(() => {
      if (sessionStorage.getItem("previous-page")) {
        window.location.href = sessionStorage.getItem("previous-page");
        localStorage.removeItem("previous-page");
      }
    }, 2500); // Wait for 5 seconds + the slight delay
  }
});

// Check for popup trigger after page reload
jQuery(document).ready(function () {

  if (localStorage.getItem("popupOpen") === "fourth") {
    localStorage.removeItem("popupOpen"); // Clear the flag
    // Add the highlight effect to the whole page
    if (isPopupOpen) return;
    isPopupOpen = true;
    jQuery("body")
      .css("position", "relative")
      .append(
        '<div class="side-menu-sign-in-button-highlight" ' +
          'style="position: absolute; top: 4px; left: 4px; ' +
          'height: calc(100% - 8px); width: calc(100% - 8px); border: 3px solid red; box-sizing: border-box; z-index: 9999;"></div>'
      );
    // Fade out the highlight effect
    jQuery(".side-menu-sign-in-button-highlight").fadeOut(2500, function () {
      jQuery(".side-menu-sign-in-button-highlight").remove();
    });
    // Run the showBugPopup function
    setTimeout(() => {
      showBugPopup("fourth", jQuery(".academy-store-menu-link"));
      jQuery(document).on("click", "#close-popup", function () {
        isPopupOpen = false; // Unlock when popup is closed
      });
      jQuery(document).on("click", "#submit-popup", function () {
        isPopupOpen = false; // Unlock when submitting
      });
    }, 3000); // Small delay after fadeout
  } else if (localStorage.getItem("manufacturer-bug") === "1") {
    localStorage.removeItem("manufacturer-bug"); // Reset the flag
    if (isPopupOpen) return;
    isPopupOpen = true;
    setTimeout(() => {
      showBugPopup("third", jQuery("#manufacturer-bug a"));
      jQuery(document).on("click", "#close-popup", function () {
        isPopupOpen = false; // Unlock when popup is closed
      });
      jQuery(document).on("click", "#submit-popup", function () {
        isPopupOpen = false; // Unlock when submitting
      });
    }, 1000); // Small delay after fadeout
  }
});

window.onbeforeunload = function () {
  // console.log('you click on back or forward button');
  var applyCouponShown = getCookie("ec_apply_coupon_shown");
  if (applyCouponShown === "true") {
    // Perform actions for returning from a page
    // For example, remove the error div
    jQuery("#ec_coupon_error").css("display", "none");
    // Reset the flag in the cookie
    eraseCookie("ec_apply_coupon_shown");
  }

  var redeemGiftCardShown = getCookie("ec_redeem_gift_card_shown");
  if (redeemGiftCardShown === "true") {
    jQuery("#ec_gift_card_error").css("display", "none");
    eraseCookie("ec_redeem_gift_card_shown");
  }
  // loadPopUpImageAndGif("third", true);
  // popupOpenAndClose(4406, function () {
  //     tooltipBugCountInfo();
  //     showHintIfBugsAreNearby("third", function () {
  //         if (jQuery(this).prop('target') === '_blank') window.open(href);
  //         else location = href;
  //     });
  // });
};

function wait(ms, fnToExecute) {
  fnToExecute = fnToExecute === undefined ? function () {} : fnToExecute;
  window.setTimeout(fnToExecute, ms);
}
jQuery(document).on("click", ".tutorial-question-mark > a", function (e) {
  e.preventDefault();
  jQuery.tourTip.start();
});
jQuery(document).on("click", "button", function (e) {
  if (jQuery(this).prop("id") == "submit-contact-form") {
    if (validateForm()) {
      console.log("form valid");
      wait(1000);
      var contactFormParent = jQuery("#contact-form").parent();
      jQuery("#contact-form").remove();
      contactFormParent.append(
        '<div style="background: #FFF5F4; ' +
          'border: 1px solid #F68B8B; color: #333; margin: 0 auto 24px; padding: 15px 15px;"' +
          'id="wpforms-confirmation-1122"><p style="margin: 0">Oops! Something went wrong.</p></div>'
      );
    }
  }

  if (e.target.id != "ok") {
    // you clicked something else
  }
  // #ec_account_shipping_information_first_name
});

jQuery(document).on("focusout", "input[type=text]", function (e) {
  var validationObj = {
    isValid: true,
  };
  jQuery(this).val(jQuery(this).val().trim());
  if (e.target.id == "ec_account_shipping_information_first_name") {
    validateAndModifyContactFormField(
      validationObj,
      jQuery(this),
      "first_name_error",
      "first_name"
    );
  }

  if (e.target.id == "ec_account_shipping_information_last_name") {
    validateAndModifyContactFormField(
      validationObj,
      jQuery(this),
      "last_name_error",
      "last_name"
    );
  }

  if (e.target.id == "ec_account_shipping_information_address") {
    validateAndModifyContactFormField(
      validationObj,
      jQuery(this),
      "address_error",
      "address"
    );
  }

  if (e.target.id == "ec_account_shipping_information_city") {
    validateAndModifyContactFormField(
      validationObj,
      jQuery(this),
      "city_error",
      "city"
    );
  }
  jQuery("#shipping_info_form_ec").prop("disabled", !validationObj.isValid);
  if (!validationObj.isValid) {
    jQuery("#shipping_info_form_ec").attr(
      "style",
      "background-color: #6c757d !important"
    );
    jQuery("#shipping_info_form_ec").css("cursor", "default");
  } else {
    jQuery("#shipping_info_form_ec").attr(
      "style",
      "background-color: #00a8cc !important"
    );
    jQuery("#shipping_info_form_ec").css("cursor", "pointer");
  }
  // console.log("e.target.id: "+e.target.id);
});

// academy update example 3
jQuery(document).on("submit", "form.cart", function (e) {
  e.preventDefault();
  window.location.replace("https://academybugs.com/");
});
